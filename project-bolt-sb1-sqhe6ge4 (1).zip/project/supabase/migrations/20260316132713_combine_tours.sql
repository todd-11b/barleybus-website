/*
  # Combine Tours into Single Options

  ## Changes Made
  
  1. Tour Consolidation
    - Combine "KC Sightseeing" and "Ghost and Gangsters" into single tour option
    - Merge all food tours (BBQ, Tacos, Margaritas) into one comprehensive "KC Food Tour"
    
  2. Updates
    - Update tour names and descriptions to reflect combined offerings
    - Adjust pricing to reflect combined tour value
    - Update tour types and categories as needed

  ## Tour Updates
  
  ### Sightseeing & History Tour
  - Combines KC Sightseeing with Ghost & Gangsters
  - New name: "KC Sightseeing & Ghost Tour"
  - Includes both historical landmarks and spooky stories
  
  ### Food Tour
  - Combines BBQ Tour, Taco Tour, and Margarita Tour
  - New name: "KC Food Tour"
  - Comprehensive culinary experience featuring BBQ, tacos, and margaritas
*/

-- First, let's check if tours exist and update them
DO $$
DECLARE
  sightseeing_id uuid;
  ghost_id uuid;
  bbq_id uuid;
  taco_id uuid;
  margarita_id uuid;
BEGIN
  -- Get IDs of tours to combine
  SELECT id INTO sightseeing_id FROM tours WHERE slug = 'kc-sightseeing' LIMIT 1;
  SELECT id INTO ghost_id FROM tours WHERE slug = 'ghost-and-gangsters' LIMIT 1;
  SELECT id INTO bbq_id FROM tours WHERE slug = 'bbq-tour' LIMIT 1;
  SELECT id INTO taco_id FROM tours WHERE slug = 'taco-tour' LIMIT 1;
  SELECT id INTO margarita_id FROM tours WHERE slug = 'margarita-tour' LIMIT 1;

  -- Combine KC Sightseeing and Ghost & Gangsters
  IF sightseeing_id IS NOT NULL AND ghost_id IS NOT NULL THEN
    -- Update the sightseeing tour to include ghost content
    UPDATE tours
    SET 
      name = 'KC Sightseeing & Ghost Tour',
      slug = 'kc-sightseeing-ghost',
      tagline = 'Explore Kansas City landmarks and haunted history',
      description = 'Experience the best of Kansas City on this combined tour! Discover iconic landmarks, historical sites, and fascinating architecture while hearing spine-tingling tales of ghosts, gangsters, and the city''s darker past. This comprehensive tour gives you both the beauty and the mystery of KC.',
      duration_hours = 3.5,
      price_from = 79,
      tour_type = 'sightseeing',
      updated_at = now()
    WHERE id = sightseeing_id;

    -- Migrate ghost tour data to sightseeing tour
    UPDATE tour_itinerary_stops SET tour_id = sightseeing_id WHERE tour_id = ghost_id;
    UPDATE tour_inclusions SET tour_id = sightseeing_id WHERE tour_id = ghost_id;
    UPDATE tour_photos SET tour_id = sightseeing_id WHERE tour_id = ghost_id;
    UPDATE reviews SET tour_id = sightseeing_id WHERE tour_id = ghost_id;
    UPDATE bookings SET tour_id = sightseeing_id WHERE tour_id = ghost_id;

    -- Delete the ghost tour
    DELETE FROM tours WHERE id = ghost_id;
  END IF;

  -- Combine BBQ, Taco, and Margarita tours into one Food Tour
  IF bbq_id IS NOT NULL THEN
    -- Update BBQ tour to be the comprehensive food tour
    UPDATE tours
    SET 
      name = 'KC Food Tour',
      slug = 'kc-food-tour',
      tagline = 'Taste the best of Kansas City - BBQ, tacos, and margaritas',
      description = 'Indulge in Kansas City''s incredible food scene on this ultimate culinary adventure! Sample world-famous Kansas City BBQ, authentic street tacos, and handcrafted margaritas. This tour hits all the best local spots and gives you a true taste of what makes KC a food lover''s paradise.',
      duration_hours = 4,
      price_from = 89,
      tour_type = 'food',
      updated_at = now()
    WHERE id = bbq_id;

    -- Migrate taco and margarita tour data if they exist
    IF taco_id IS NOT NULL THEN
      UPDATE tour_itinerary_stops SET tour_id = bbq_id WHERE tour_id = taco_id;
      UPDATE tour_inclusions SET tour_id = bbq_id WHERE tour_id = taco_id;
      UPDATE tour_photos SET tour_id = bbq_id WHERE tour_id = taco_id;
      UPDATE reviews SET tour_id = bbq_id WHERE tour_id = taco_id;
      UPDATE bookings SET tour_id = bbq_id WHERE tour_id = taco_id;
      DELETE FROM tours WHERE id = taco_id;
    END IF;

    IF margarita_id IS NOT NULL THEN
      UPDATE tour_itinerary_stops SET tour_id = bbq_id WHERE tour_id = margarita_id;
      UPDATE tour_inclusions SET tour_id = bbq_id WHERE tour_id = margarita_id;
      UPDATE tour_photos SET tour_id = bbq_id WHERE tour_id = margarita_id;
      UPDATE reviews SET tour_id = bbq_id WHERE tour_id = margarita_id;
      UPDATE bookings SET tour_id = bbq_id WHERE tour_id = margarita_id;
      DELETE FROM tours WHERE id = margarita_id;
    END IF;
  END IF;
END $$;
