/*
  # Add Upload Policy for Website Downloads

  1. Security
    - Allow public uploads to website-downloads bucket (for admin use)
*/

CREATE POLICY "Allow public uploads to website-downloads"
  ON storage.objects
  FOR INSERT
  WITH CHECK (bucket_id = 'website-downloads');
