/*
  # Create Storage Bucket for Exports
  
  1. New Storage Bucket
    - `exports` - Public bucket for downloadable files
  
  2. Security
    - Public access for downloads
    - Anyone can read files
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('exports', 'exports', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public can read exports"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'exports');
