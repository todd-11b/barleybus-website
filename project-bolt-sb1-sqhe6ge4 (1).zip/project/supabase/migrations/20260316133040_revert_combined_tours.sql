/*
  # Revert Tour Combinations - Restore Individual Tours

  ## Changes Made
  
  1. Restore Individual Tours
    - Recreate separate tours for KC Sightseeing, Ghost & Gangsters
    - Recreate separate food tours for BBQ, Tacos, and Margaritas
    - Remove the combined tour entries
    
  2. Tour Structure
    - Each tour maintains its own identity and pricing
    - Proper categorization for calculator integration

  ## Tours Restored
  
  ### Sightseeing Tours
  - KC Sightseeing
  - Ghost & Gangsters
  - Instagram Tour
  
  ### Food Tours
  - BBQ Tour
  - Tacos & Margaritas Tour
  
  ### Drink Tours
  - Brewery/Winery/Distillery Tour
*/

-- Remove combined tours if they exist
DELETE FROM tours WHERE slug IN ('kc-sightseeing-ghost', 'kc-food-tour');

-- Insert/Update individual tours
INSERT INTO tours (slug, name, tagline, description, duration_hours, price_from, max_capacity, tour_type, featured, active)
VALUES 
  -- Sightseeing Tours
  ('kc-sightseeing', 'KC Sightseeing', 'Discover Kansas City landmarks and history', 'Explore the best of Kansas City on this comprehensive sightseeing tour. Visit iconic landmarks, learn about the city''s rich history, and see all the must-visit spots that make KC special.', 2.5, 49, 20, 'sightseeing', true, true),
  
  ('ghost-and-gangsters', 'Ghost & Gangsters', 'Haunted history and notorious criminals of Kansas City', 'Uncover the darker side of Kansas City on this thrilling tour. Hear spine-tingling ghost stories, learn about notorious gangsters, and visit haunted locations throughout the city.', 2.5, 59, 20, 'sightseeing', false, true),
  
  ('instagram-tour', 'Instagram Tour', 'Kansas City''s most photogenic spots', 'Capture stunning photos at Kansas City''s most Instagram-worthy locations. Perfect for influencers and photography enthusiasts looking for that perfect shot.', 2, 45, 20, 'sightseeing', false, true),
  
  -- Food Tours
  ('bbq-tour', 'BBQ Tour', 'Taste world-famous Kansas City barbecue', 'Experience the legendary Kansas City BBQ scene. Sample mouth-watering ribs, brisket, and burnt ends at the city''s best barbecue joints.', 3, 79, 20, 'food', true, true),
  
  ('tacos-and-margs', 'Tacos & Margaritas', 'Authentic tacos and handcrafted margaritas', 'Enjoy the best tacos and margaritas in Kansas City. Visit local favorites and hidden gems for an authentic culinary experience.', 3, 69, 20, 'food', false, true),
  
  -- Drink Tours
  ('brewery-winery-distillery', 'Brewery/Winery/Distillery Tour', 'Sample local craft beverages', 'Tour Kansas City''s finest breweries, wineries, and distilleries. Taste craft beers, local wines, and artisan spirits while learning about the production process.', 3.5, 75, 20, 'brewery', true, true)
  
ON CONFLICT (slug) 
DO UPDATE SET
  name = EXCLUDED.name,
  tagline = EXCLUDED.tagline,
  description = EXCLUDED.description,
  duration_hours = EXCLUDED.duration_hours,
  price_from = EXCLUDED.price_from,
  tour_type = EXCLUDED.tour_type,
  featured = EXCLUDED.featured,
  active = EXCLUDED.active,
  updated_at = now();
