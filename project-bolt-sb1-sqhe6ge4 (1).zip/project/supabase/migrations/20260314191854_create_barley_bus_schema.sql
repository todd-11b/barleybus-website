/*
  # Barley Bus Tour Booking System - Complete Schema

  ## Overview
  This migration creates the complete database structure for the Barley Bus tour booking platform,
  designed to support high-conversion booking flows, private event management, and comprehensive
  review/social proof systems.

  ## Tables Created
  
  ### 1. tours
  Core tour inventory with pricing, capacity, and availability
  - `id` (uuid, primary key)
  - `slug` (text, unique) - URL-friendly identifier
  - `name` (text) - Tour display name
  - `tagline` (text) - Short hook for cards
  - `description` (text) - Full tour description
  - `duration_hours` (numeric) - Tour duration
  - `price_from` (numeric) - Starting price per person
  - `max_capacity` (integer) - Maximum guests per tour
  - `tour_type` (text) - Category: brewery, bbq, ghost, sightseeing, holiday, party_bus
  - `featured` (boolean) - Featured tour flag
  - `active` (boolean) - Tour is bookable
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 2. tour_itinerary_stops
  Itinerary/stops for each tour (especially Ghost & Gangsters, Brewery)
  - `id` (uuid, primary key)
  - `tour_id` (uuid, foreign key)
  - `stop_number` (integer) - Order in itinerary
  - `name` (text) - Stop name
  - `description` (text) - What happens here
  - `duration_minutes` (integer) - Time at this stop

  ### 3. tour_inclusions
  What's included/not included in each tour
  - `id` (uuid, primary key)
  - `tour_id` (uuid, foreign key)
  - `item` (text) - Inclusion description
  - `included` (boolean) - true = included, false = bring your own
  - `sort_order` (integer)

  ### 4. tour_photos
  Photo gallery for each tour
  - `id` (uuid, primary key)
  - `tour_id` (uuid, foreign key)
  - `url` (text) - Photo URL
  - `caption` (text, optional)
  - `is_hero` (boolean) - Main tour photo
  - `sort_order` (integer)

  ### 5. reviews
  Tour-specific reviews with star ratings
  - `id` (uuid, primary key)
  - `tour_id` (uuid, foreign key, nullable) - null = general company review
  - `guest_name` (text)
  - `rating` (integer) - 1-5 stars
  - `review_text` (text)
  - `review_date` (date)
  - `verified` (boolean) - Verified booking
  - `created_at` (timestamptz)

  ### 6. bookings
  Tour booking records (synced from GHL)
  - `id` (uuid, primary key)
  - `tour_id` (uuid, foreign key)
  - `ghl_contact_id` (text) - GoHighLevel contact ID
  - `guest_name` (text)
  - `guest_email` (text)
  - `guest_phone` (text)
  - `tour_date` (date)
  - `guest_count` (integer)
  - `total_price` (numeric)
  - `deposit_paid` (numeric)
  - `status` (text) - pending, confirmed, completed, cancelled
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 7. private_event_inquiries
  Lead capture for corporate/private events
  - `id` (uuid, primary key)
  - `name` (text)
  - `email` (text)
  - `phone` (text)
  - `event_date` (date, nullable)
  - `guest_count` (integer, nullable)
  - `event_type` (text) - bachelorette, corporate, birthday, team_building, custom
  - `message` (text)
  - `status` (text) - new, contacted, quoted, booked, declined
  - `ghl_opportunity_id` (text, nullable) - GoHighLevel pipeline opportunity ID
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 8. faqs
  Frequently asked questions
  - `id` (uuid, primary key)
  - `question` (text)
  - `answer` (text)
  - `category` (text) - general, booking, tours, private_events
  - `sort_order` (integer)
  - `active` (boolean)

  ### 9. ugc_photos
  User-generated content / Wall of Love
  - `id` (uuid, primary key)
  - `instagram_url` (text, nullable)
  - `photo_url` (text)
  - `caption` (text, nullable)
  - `guest_name` (text, nullable)
  - `tour_id` (uuid, foreign key, nullable)
  - `featured` (boolean)
  - `created_at` (timestamptz)

  ## Security
  - RLS enabled on all tables
  - Public read access for tours, reviews, FAQs, UGC
  - Authenticated admin access for bookings and inquiries
  - Insert-only public access for private event inquiries (lead capture)

  ## Indexes
  - Tours: slug, tour_type, featured, active
  - Reviews: tour_id, rating
  - Bookings: tour_id, tour_date, status
*/

-- Create tours table
CREATE TABLE IF NOT EXISTS tours (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  name text NOT NULL,
  tagline text NOT NULL,
  description text NOT NULL,
  duration_hours numeric NOT NULL,
  price_from numeric NOT NULL,
  max_capacity integer NOT NULL DEFAULT 20,
  tour_type text NOT NULL,
  featured boolean DEFAULT false,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create tour_itinerary_stops table
CREATE TABLE IF NOT EXISTS tour_itinerary_stops (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tour_id uuid REFERENCES tours(id) ON DELETE CASCADE NOT NULL,
  stop_number integer NOT NULL,
  name text NOT NULL,
  description text NOT NULL,
  duration_minutes integer DEFAULT 30
);

-- Create tour_inclusions table
CREATE TABLE IF NOT EXISTS tour_inclusions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tour_id uuid REFERENCES tours(id) ON DELETE CASCADE NOT NULL,
  item text NOT NULL,
  included boolean DEFAULT true,
  sort_order integer DEFAULT 0
);

-- Create tour_photos table
CREATE TABLE IF NOT EXISTS tour_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tour_id uuid REFERENCES tours(id) ON DELETE CASCADE NOT NULL,
  url text NOT NULL,
  caption text,
  is_hero boolean DEFAULT false,
  sort_order integer DEFAULT 0
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tour_id uuid REFERENCES tours(id) ON DELETE SET NULL,
  guest_name text NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_text text NOT NULL,
  review_date date DEFAULT CURRENT_DATE,
  verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tour_id uuid REFERENCES tours(id) ON DELETE SET NULL NOT NULL,
  ghl_contact_id text,
  guest_name text NOT NULL,
  guest_email text NOT NULL,
  guest_phone text NOT NULL,
  tour_date date NOT NULL,
  guest_count integer NOT NULL,
  total_price numeric NOT NULL,
  deposit_paid numeric DEFAULT 0,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create private_event_inquiries table
CREATE TABLE IF NOT EXISTS private_event_inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  event_date date,
  guest_count integer,
  event_type text NOT NULL,
  message text NOT NULL,
  status text DEFAULT 'new',
  ghl_opportunity_id text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create faqs table
CREATE TABLE IF NOT EXISTS faqs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  answer text NOT NULL,
  category text NOT NULL DEFAULT 'general',
  sort_order integer DEFAULT 0,
  active boolean DEFAULT true
);

-- Create ugc_photos table
CREATE TABLE IF NOT EXISTS ugc_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  instagram_url text,
  photo_url text NOT NULL,
  caption text,
  guest_name text,
  tour_id uuid REFERENCES tours(id) ON DELETE SET NULL,
  featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_tours_slug ON tours(slug);
CREATE INDEX IF NOT EXISTS idx_tours_type ON tours(tour_type);
CREATE INDEX IF NOT EXISTS idx_tours_featured ON tours(featured);
CREATE INDEX IF NOT EXISTS idx_tours_active ON tours(active);
CREATE INDEX IF NOT EXISTS idx_reviews_tour_id ON reviews(tour_id);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews(rating);
CREATE INDEX IF NOT EXISTS idx_bookings_tour_id ON bookings(tour_id);
CREATE INDEX IF NOT EXISTS idx_bookings_tour_date ON bookings(tour_date);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_itinerary_tour_id ON tour_itinerary_stops(tour_id);
CREATE INDEX IF NOT EXISTS idx_inclusions_tour_id ON tour_inclusions(tour_id);
CREATE INDEX IF NOT EXISTS idx_photos_tour_id ON tour_photos(tour_id);
CREATE INDEX IF NOT EXISTS idx_ugc_featured ON ugc_photos(featured);

-- Enable Row Level Security
ALTER TABLE tours ENABLE ROW LEVEL SECURITY;
ALTER TABLE tour_itinerary_stops ENABLE ROW LEVEL SECURITY;
ALTER TABLE tour_inclusions ENABLE ROW LEVEL SECURITY;
ALTER TABLE tour_photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE private_event_inquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE faqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE ugc_photos ENABLE ROW LEVEL SECURITY;

-- RLS Policies: Public read access for content tables

CREATE POLICY "Public can view active tours"
  ON tours FOR SELECT
  USING (active = true);

CREATE POLICY "Public can view tour stops"
  ON tour_itinerary_stops FOR SELECT
  USING (true);

CREATE POLICY "Public can view tour inclusions"
  ON tour_inclusions FOR SELECT
  USING (true);

CREATE POLICY "Public can view tour photos"
  ON tour_photos FOR SELECT
  USING (true);

CREATE POLICY "Public can view reviews"
  ON reviews FOR SELECT
  USING (true);

CREATE POLICY "Public can view active FAQs"
  ON faqs FOR SELECT
  USING (active = true);

CREATE POLICY "Public can view featured UGC"
  ON ugc_photos FOR SELECT
  USING (featured = true);

-- RLS Policies: Lead capture - public can insert private event inquiries

CREATE POLICY "Anyone can submit private event inquiry"
  ON private_event_inquiries FOR INSERT
  WITH CHECK (true);

-- RLS Policies: Admin access for authenticated users (GHL webhook or admin panel)

CREATE POLICY "Authenticated users can manage tours"
  ON tours FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can manage bookings"
  ON bookings FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view inquiries"
  ON private_event_inquiries FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can update inquiries"
  ON private_event_inquiries FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);