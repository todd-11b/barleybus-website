/*
  # Create Website Downloads Storage Bucket

  1. New Storage
    - `website-downloads` bucket for storing downloadable files
  
  2. Security
    - Public bucket so files are accessible without authentication
    - Anyone can download files
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('website-downloads', 'website-downloads', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public can download files"
  ON storage.objects
  FOR SELECT
  USING (bucket_id = 'website-downloads');
