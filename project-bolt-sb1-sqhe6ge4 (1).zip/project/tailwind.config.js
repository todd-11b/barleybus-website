/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Clash Display', 'sans-serif'],
        sans: ['General Sans', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      textStroke: {
        sm: '1px',
        DEFAULT: '2px',
        lg: '3px',
      },
    },
  },
  plugins: [
    function({ addUtilities }) {
      addUtilities({
        '.text-stroke': {
          '-webkit-text-stroke': '2px rgba(255, 255, 255, 0.2)',
          '-webkit-text-fill-color': 'transparent',
          'paint-order': 'stroke fill',
        },
        '.text-stroke-lg': {
          '-webkit-text-stroke': '3px rgba(255, 255, 255, 0.2)',
          '-webkit-text-fill-color': 'transparent',
          'paint-order': 'stroke fill',
        },
      })
    }
  ],
};
