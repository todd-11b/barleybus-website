import { Star, Users, Award } from 'lucide-react';

export default function TrustBar() {
  return (
    <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 md:gap-8 text-white text-sm sm:text-base">
      <div className="flex items-center gap-1.5 sm:gap-2">
        <div className="flex">
          {[...Array(5)].map((_, i) => (
            <Star key={i} className="w-4 h-4 sm:w-5 sm:h-5 fill-yellow-400 text-yellow-400" />
          ))}
        </div>
        <span className="font-semibold">4.9/5 (500+ reviews)</span>
      </div>
      <div className="flex items-center gap-1.5 sm:gap-2">
        <Users className="w-4 h-4 sm:w-5 sm:h-5" />
        <span className="font-semibold">15,000+ Happy Guests</span>
      </div>
      <div className="flex items-center gap-1.5 sm:gap-2">
        <Award className="w-4 h-4 sm:w-5 sm:h-5" />
        <span className="font-semibold">8 Years in Business</span>
      </div>
    </div>
  );
}
