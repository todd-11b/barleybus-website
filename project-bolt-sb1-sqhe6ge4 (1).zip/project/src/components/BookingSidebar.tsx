import { Calendar, Users, Shield, Clock } from 'lucide-react';
import { Tour } from '../lib/supabase';

interface BookingSidebarProps {
  tour: Tour;
  spotsLeft?: number;
}

export default function BookingSidebar({ tour, spotsLeft = 4 }: BookingSidebarProps) {
  const handleCheckAvailability = () => {
    window.location.href = `https://book.barleybus.com/${tour.slug}`;
  };

  return (
    <div className="sticky top-20 sm:top-24 bg-white rounded-lg shadow-xl border border-gray-200 p-4 sm:p-5 md:p-6 space-y-4 sm:space-y-5 md:space-y-6">
      <div>
        <div className="text-xs sm:text-sm text-gray-600 mb-1">From</div>
        <div className="text-3xl sm:text-4xl font-bold text-gray-900">${Math.floor(tour.price_from)}</div>
        <div className="text-xs sm:text-sm text-gray-600">per person</div>
      </div>

      {spotsLeft <= 5 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-semibold text-red-700">
              Only {spotsLeft} spots left!
            </span>
          </div>
        </div>
      )}

      <div className="space-y-3 py-4 border-y border-gray-200">
        <div className="flex items-center gap-3 text-gray-700">
          <Clock className="w-5 h-5 text-amber-600" />
          <span className="text-sm">{tour.duration_hours} hours</span>
        </div>
        <div className="flex items-center gap-3 text-gray-700">
          <Users className="w-5 h-5 text-amber-600" />
          <span className="text-sm">Max {tour.max_capacity} guests</span>
        </div>
        <div className="flex items-center gap-3 text-gray-700">
          <Calendar className="w-5 h-5 text-amber-600" />
          <span className="text-sm">Book online in 60 seconds</span>
        </div>
      </div>

      <button
        onClick={handleCheckAvailability}
        className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-3 px-4 sm:py-4 sm:px-6 text-sm sm:text-base rounded-lg transition-colors duration-200 shadow-lg hover:shadow-xl min-h-[48px]"
      >
        Check Availability
      </button>

      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs sm:text-sm text-gray-600">
          <Shield className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-green-600 flex-shrink-0" />
          <span>Free cancellation up to 24 hours</span>
        </div>
        <div className="flex items-center gap-2 text-xs sm:text-sm text-gray-600">
          <Shield className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-green-600 flex-shrink-0" />
          <span>100% satisfaction guarantee</span>
        </div>
      </div>
    </div>
  );
}
