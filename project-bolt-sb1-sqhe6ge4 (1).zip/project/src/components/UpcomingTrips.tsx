import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useRef, useEffect } from 'react';

interface Trip {
  id: string;
  title: string;
  description: string;
  price: string;
  image: string;
  category: string;
}

const trips: Trip[] = [
  {
    id: '1',
    title: 'KC Food Tour',
    description: 'Explore Kansas City\'s best culinary experiences',
    price: '89',
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Food'
  },
  {
    id: '2',
    title: 'Brewery Tour',
    description: 'Discover Kansas City\'s craft beer scene',
    price: '79',
    image: 'https://images.pexels.com/photos/5538334/pexels-photo-5538334.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Drink'
  },
  {
    id: '3',
    title: 'KC Sightseeing',
    description: 'Experience iconic Kansas City landmarks',
    price: '69',
    image: 'https://images.pexels.com/photos/1388030/pexels-photo-1388030.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Sightseeing'
  },
  {
    id: '4',
    title: 'Distillery Tour',
    description: 'Sample the finest spirits in Kansas City',
    price: '85',
    image: 'https://images.pexels.com/photos/6686442/pexels-photo-6686442.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Drink'
  },
  {
    id: '5',
    title: 'Private Event',
    description: 'Custom tour experience for your group',
    price: '299',
    image: 'https://images.pexels.com/photos/2531608/pexels-photo-2531608.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Private'
  },
  {
    id: '6',
    title: 'Winery Tour',
    description: 'Taste the best wines Kansas City has to offer',
    price: '95',
    image: 'https://images.pexels.com/photos/1407846/pexels-photo-1407846.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Drink'
  }
];

export default function UpcomingTrips() {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 400;
      const newPosition = direction === 'left'
        ? scrollContainerRef.current.scrollLeft - scrollAmount
        : scrollContainerRef.current.scrollLeft + scrollAmount;

      scrollContainerRef.current.scrollTo({
        left: newPosition,
        behavior: 'smooth'
      });
    }
  };

  useEffect(() => {
    const autoScroll = () => {
      if (scrollContainerRef.current) {
        const container = scrollContainerRef.current;
        const maxScroll = container.scrollWidth - container.clientWidth;

        if (container.scrollLeft >= maxScroll) {
          container.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
          container.scrollTo({
            left: container.scrollLeft + 320,
            behavior: 'smooth'
          });
        }
      }
    };

    const intervalId = setInterval(autoScroll, 3000);
    return () => clearInterval(intervalId);
  }, []);

  return (
    <section className="py-10 sm:py-16 md:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start mb-6 sm:mb-8 md:mb-12 gap-4 sm:gap-6">
          <div className="max-w-xl">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-2 sm:mb-3 md:mb-4">
              UPCOMING TRIPS
            </h2>
            <p className="text-gray-600 text-sm sm:text-base md:text-lg mb-3 sm:mb-4 md:mb-6 leading-relaxed">
              Exciting upcoming trips to breweries, distilleries, wineries, and Kansas City landmarks.
              Adventure, culture, and unforgettable memories await you soon!
            </p>
            <a href="/packages" className="inline-block bg-orange-600 hover:bg-orange-700 text-white font-semibold px-5 py-2.5 sm:px-8 sm:py-3 rounded-lg transition-colors text-sm sm:text-base min-h-[44px] shadow-lg hover:shadow-xl">
              View All
            </a>
          </div>

          <div className="flex gap-2 self-end md:self-auto">
            <button
              onClick={() => scroll('left')}
              className="p-2.5 sm:p-3 rounded-full bg-white hover:bg-gray-100 border border-gray-200 transition-colors min-h-[44px] min-w-[44px]"
              aria-label="Scroll left"
            >
              <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 text-gray-900" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="p-2.5 sm:p-3 rounded-full bg-white hover:bg-gray-100 border border-gray-200 transition-colors min-h-[44px] min-w-[44px]"
              aria-label="Scroll right"
            >
              <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6 text-gray-900" />
            </button>
          </div>
        </div>

        <div
          ref={scrollContainerRef}
          className="flex gap-3 sm:gap-4 md:gap-6 overflow-x-auto scrollbar-hide snap-x snap-mandatory pb-4 -mx-3 px-3 sm:mx-0 sm:px-0"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {trips.map((trip) => (
            <a
              key={trip.id}
              href="/packages"
              className="flex-none w-[240px] sm:w-[280px] md:w-[300px] snap-start group"
            >
              <div className="relative h-[320px] sm:h-[380px] md:h-[450px] rounded-xl sm:rounded-2xl overflow-hidden shadow-lg cursor-pointer">
                <img
                  src={trip.image}
                  alt={trip.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />

                <div className="absolute bottom-0 left-0 right-0 p-3 sm:p-4 md:p-6 text-white">
                  <div className="flex items-end justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <h3 className="text-lg sm:text-xl md:text-2xl font-bold mb-1 uppercase truncate">
                        {trip.title}
                      </h3>
                      <p className="text-xs sm:text-sm text-gray-200 mb-2 line-clamp-2">
                        {trip.description}
                      </p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="text-xs text-amber-300 font-semibold mb-0.5 sm:mb-1 tracking-wider">FROM</div>
                      <div className="text-xl sm:text-2xl md:text-3xl font-bold text-amber-300">${trip.price}</div>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
