import { useState, useEffect } from 'react';

interface StickyBookButtonProps {
  tourSlug?: string;
  className?: string;
}

export default function StickyBookButton({ tourSlug, className = '' }: StickyBookButtonProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleBooking = () => {
    const bookingUrl = tourSlug
      ? `https://book.barleybus.com/${tourSlug}`
      : 'https://book.barleybus.com';
    window.location.href = bookingUrl;
  };

  return (
    <>
      <button
        onClick={handleBooking}
        className={`fixed bottom-0 left-0 right-0 z-50 bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-4 text-sm sm:text-base sm:py-4 sm:px-6 transition-all duration-300 shadow-2xl md:hidden min-h-[48px] ${
          isVisible ? 'translate-y-0' : 'translate-y-full'
        } ${className}`}
      >
        Check Availability
      </button>

      <button
        onClick={handleBooking}
        className={`hidden md:block fixed top-20 right-4 lg:right-6 z-50 bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-6 lg:px-8 text-sm lg:text-base rounded-lg shadow-2xl transition-all duration-300 min-h-[48px] ${
          isVisible ? 'translate-y-0 opacity-100' : '-translate-y-20 opacity-0 pointer-events-none'
        } ${className}`}
      >
        Book Now
      </button>
    </>
  );
}
