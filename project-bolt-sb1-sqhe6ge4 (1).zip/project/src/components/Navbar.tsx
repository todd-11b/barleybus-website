import { useState, useEffect } from 'react';
import { Phone, Menu, X, ChevronDown } from 'lucide-react';
import Button from './Button';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isToursDropdownOpen, setIsToursDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white shadow-lg py-3' : 'bg-transparent py-5'
    }`}>
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <a href="/" className="flex items-center">
              <img
                src={isScrolled ? "/Barleybus_logo_blk.png" : "/Barley_Bus_Logo_Only.png"}
                alt="Barley Bus"
                className={`transition-all duration-300 ${isScrolled ? 'h-8 sm:h-10' : 'h-10 sm:h-12'}`}
              />
            </a>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <div
              className="relative group"
              onMouseEnter={() => setIsToursDropdownOpen(true)}
              onMouseLeave={() => setIsToursDropdownOpen(false)}
            >
              <button className={`font-medium transition-colors flex items-center gap-1 ${
                isScrolled ? 'text-slate-700 hover:text-orange-600' : 'text-white hover:text-orange-300'
              }`}>
                Tours
                <ChevronDown className={`w-4 h-4 transition-transform ${isToursDropdownOpen ? 'rotate-180' : ''}`} />
              </button>
              {isToursDropdownOpen && (
                <div className="absolute top-full left-0 pt-2 z-50">
                  <div className="w-40 sm:w-48 bg-white rounded-lg shadow-lg py-2 border border-slate-200">
                    <a href="/packages" className="block px-4 py-2 text-slate-700 hover:bg-orange-50 hover:text-orange-600 transition-colors">
                      All Tours
                    </a>
                    <a href="/tours/kc-brewery-tour" className="block px-4 py-2 text-slate-700 hover:bg-orange-50 hover:text-orange-600 transition-colors">
                      KC Brewery Tour
                    </a>
                  </div>
                </div>
              )}
            </div>
            <a href="/party-bus" className={`font-medium transition-colors ${
              isScrolled ? 'text-slate-700 hover:text-orange-600' : 'text-white hover:text-orange-300'
            }`}>
              Party Bus
            </a>
            <a href="/private-events" className={`font-medium transition-colors ${
              isScrolled ? 'text-slate-700 hover:text-orange-600' : 'text-white hover:text-orange-300'
            }`}>
              Private Events
            </a>
            <a href="/about" className={`font-medium transition-colors ${
              isScrolled ? 'text-slate-700 hover:text-orange-600' : 'text-white hover:text-orange-300'
            }`}>
              About
            </a>
            <a href="tel:+18165550100" className={`flex items-center gap-2 font-medium transition-colors ${
              isScrolled ? 'text-slate-700 hover:text-orange-600' : 'text-white hover:text-orange-300'
            }`}>
              <Phone className="w-4 h-4" />
              (816) 555-0100
            </a>
            <Button href="https://book.barleybus.com" size="sm">Book Now</Button>
          </div>

          <button
            className={`md:hidden ${isScrolled ? 'text-slate-900' : 'text-white'}`}
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 pb-3 bg-white rounded-lg shadow-lg max-h-[calc(100vh-80px)] overflow-y-auto">
            <div className="flex flex-col gap-3 p-3">
              <div>
                <div className="text-slate-700 font-medium mb-2">Tours</div>
                <div className="flex flex-col gap-2 pl-4">
                  <a href="/packages" className="text-slate-600 hover:text-orange-600">All Tours</a>
                  <a href="/tours/kc-brewery-tour" className="text-slate-600 hover:text-orange-600">KC Brewery Tour</a>
                </div>
              </div>
              <a href="/party-bus" className="text-slate-700 font-medium hover:text-orange-600">Party Bus</a>
              <a href="/private-events" className="text-slate-700 font-medium hover:text-orange-600">Private Events</a>
              <a href="/about" className="text-slate-700 font-medium hover:text-orange-600">About</a>
              <a href="tel:+18165550100" className="flex items-center gap-2 text-slate-700 font-medium hover:text-orange-600">
                <Phone className="w-4 h-4" />
                (816) 555-0100
              </a>
              <Button href="https://book.barleybus.com" size="md" className="w-full">Book Now</Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
