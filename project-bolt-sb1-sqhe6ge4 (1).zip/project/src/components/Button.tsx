import { Link } from 'react-router-dom';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  onClick?: () => void;
  className?: string;
  href?: string;
}

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  onClick,
  className = '',
  href
}: ButtonProps) {
  const baseStyles = 'font-semibold transition-all duration-200 rounded-lg inline-flex items-center justify-center';

  const variants = {
    primary: 'bg-orange-600 hover:bg-orange-700 text-white shadow-lg hover:shadow-xl',
    secondary: 'bg-slate-900 hover:bg-slate-800 text-white shadow-md hover:shadow-lg',
    ghost: 'border-2 border-white text-white hover:bg-white hover:text-orange-600'
  };

  const sizes = {
    sm: 'px-3 py-2 sm:px-4 sm:py-2 text-sm min-h-[44px]',
    md: 'px-4 py-3 sm:px-6 sm:py-3 text-sm sm:text-base min-h-[44px]',
    lg: 'px-6 py-3 sm:px-8 sm:py-4 text-base sm:text-lg min-h-[48px] sm:min-h-[52px]'
  };

  const classes = `${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`;

  if (href) {
    return (
      <Link to={href} className={classes}>
        {children}
      </Link>
    );
  }

  return (
    <button onClick={onClick} className={classes}>
      {children}
    </button>
  );
}
