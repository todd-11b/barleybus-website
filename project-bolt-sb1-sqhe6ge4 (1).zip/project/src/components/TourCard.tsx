import { Star } from 'lucide-react';
import Button from './Button';

interface TourCardProps {
  title: string;
  description: string;
  priceFrom: number;
  image: string;
  rating: number;
  href: string;
}

export default function TourCard({ title, description, priceFrom, image, rating, href }: TourCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden group">
      <div className="relative h-48 sm:h-56 md:h-64 overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-3 right-3 sm:top-4 sm:right-4 bg-white px-2.5 py-1 sm:px-3 sm:py-1 rounded-full flex items-center gap-1">
          <Star className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-yellow-400 text-yellow-400" />
          <span className="font-semibold text-xs sm:text-sm">{rating}</span>
        </div>
      </div>
      <div className="p-4 sm:p-5 md:p-6">
        <h3 className="text-lg sm:text-xl font-bold text-slate-900 mb-2">{title}</h3>
        <p className="text-sm sm:text-base text-slate-600 mb-4 line-clamp-2">{description}</p>
        <div className="flex items-center justify-between gap-3">
          <div>
            <span className="text-xs sm:text-sm text-slate-500">From</span>
            <p className="text-xl sm:text-2xl font-bold text-orange-600">${priceFrom}</p>
            <span className="text-xs text-slate-500">per person</span>
          </div>
          <Button href={href} size="sm">Book Now</Button>
        </div>
      </div>
    </div>
  );
}
