import { Star, Quote, Award } from 'lucide-react';

export default function SocialProof() {
  return (
    <section className="py-12 sm:py-20 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center">
          <div>
            <div className="flex items-center gap-2 mb-4 sm:mb-6">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 sm:w-8 h-6 sm:h-8 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <span className="text-xl sm:text-2xl font-bold ml-2">4.9/5</span>
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">
              What Our Guests Say
            </h2>

            <div className="grid grid-cols-2 gap-3 sm:gap-6 mb-6 sm:mb-8">
              <div className="text-center p-4 sm:p-6 bg-white/10 rounded-lg backdrop-blur-sm">
                <p className="text-3xl sm:text-4xl font-bold text-orange-400 mb-1 sm:mb-2">500+</p>
                <p className="text-slate-300 text-sm sm:text-base">Google Reviews</p>
              </div>
              <div className="text-center p-4 sm:p-6 bg-white/10 rounded-lg backdrop-blur-sm">
                <p className="text-3xl sm:text-4xl font-bold text-orange-400 mb-1 sm:mb-2">15K+</p>
                <p className="text-slate-300 text-sm sm:text-base">Happy Guests</p>
              </div>
            </div>

            <div className="flex items-center gap-4 sm:gap-6">
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg backdrop-blur-sm">
                <Award className="w-6 h-6 text-orange-400" />
                <span className="font-semibold text-sm sm:text-base">Google Reviews</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg backdrop-blur-sm">
                <Award className="w-6 h-6 text-orange-400" />
                <span className="font-semibold text-sm sm:text-base">TripAdvisor</span>
              </div>
            </div>
          </div>

          <div className="space-y-4 sm:space-y-6">
            <div className="bg-white text-slate-900 p-6 sm:p-8 rounded-xl shadow-2xl relative">
              <Quote className="w-8 sm:w-12 h-8 sm:h-12 text-orange-500 mb-4 opacity-20 absolute top-4 right-4" />
              <div className="flex mb-2 sm:mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 sm:w-5 h-4 sm:h-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-base sm:text-lg mb-3 sm:mb-4 leading-relaxed">
                "Best tour experience in Kansas City! Our guide was hilarious and knowledgeable. The brewery stops were perfectly chosen, and we discovered new favorite beers. Absolutely recommend for anyone visiting KC!"
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 sm:w-12 h-10 sm:h-12 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-base sm:text-lg">
                  SM
                </div>
                <div>
                  <p className="font-bold text-sm sm:text-base">Sarah M.</p>
                  <p className="text-xs sm:text-sm text-slate-600">Brewery Tour, October 2024</p>
                </div>
              </div>
            </div>

            <div className="bg-white text-slate-900 p-6 sm:p-8 rounded-xl shadow-2xl relative">
              <Quote className="w-8 sm:w-12 h-8 sm:h-12 text-orange-500 mb-4 opacity-20 absolute top-4 right-4" />
              <div className="flex mb-2 sm:mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 sm:w-5 h-4 sm:h-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-base sm:text-lg mb-3 sm:mb-4 leading-relaxed">
                "We used Barley Bus for my wife's bachelorette party and it was PERFECT. The party bus was clean, fun, and our driver was professional. Made planning so easy!"
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 sm:w-12 h-10 sm:h-12 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-base sm:text-lg">
                  JD
                </div>
                <div>
                  <p className="font-bold text-sm sm:text-base">James D.</p>
                  <p className="text-xs sm:text-sm text-slate-600">Party Bus, September 2024</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
