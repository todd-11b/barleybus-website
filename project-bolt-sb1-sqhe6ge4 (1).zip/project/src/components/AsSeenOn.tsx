const AsSeenOn = () => {
  const logos = [
    { name: 'The Kansas City Star', width: 'w-32 sm:w-36 md:w-40' },
    { name: 'The Sun', width: 'w-28 sm:w-32 md:w-36' },
    { name: 'Daily Mail', width: 'w-32 sm:w-36 md:w-40' },
    { name: 'New York Post', width: 'w-32 sm:w-36 md:w-40' },
  ];

  return (
    <div className="py-10 sm:py-12 md:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center text-slate-900 mb-8 sm:mb-10 md:mb-12">
          AS SEEN ON
        </h2>

        <div className="relative overflow-hidden">
          <div className="flex animate-scroll-left">
            {[...logos, ...logos, ...logos].map((logo, idx) => (
              <div
                key={idx}
                className="flex items-center justify-center px-4 sm:px-6 md:px-8 flex-shrink-0"
              >
                <div className={`${logo.width} h-12 sm:h-14 md:h-16 flex items-center justify-center`}>
                  <span className="text-lg sm:text-xl md:text-2xl font-bold text-slate-800 whitespace-nowrap">
                    {logo.name}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AsSeenOn;
