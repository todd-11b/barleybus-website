import { useState } from 'react';
import Button from './Button';
import TourCategoryModal from './TourCategoryModal';

export default function Hero() {
  const [isTourModalOpen, setIsTourModalOpen] = useState(false);

  return (
    <>
      <section className="relative min-h-[100svh] flex items-end overflow-hidden pt-20">
        <img
          src="/sightseeing.webp"
          alt="Kansas City skyline"
          className="absolute inset-0 w-full h-full object-cover"
        />

        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/10" />

        <div className="relative z-10 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pb-20 sm:pb-24 lg:pb-28">
          <div className="relative mb-6 sm:mb-8 md:mb-12">
            <h2 className="text-3xl sm:text-5xl md:text-7xl lg:text-8xl xl:text-9xl font-bold text-white leading-[0.95] tracking-tighter uppercase mb-3 sm:mb-4 md:mb-6">
              KANSAS CITY
            </h2>
            <h1 className="text-[4rem] sm:text-[8rem] md:text-[14rem] lg:text-[20rem] font-bold text-white leading-none tracking-tighter opacity-25 sm:opacity-45 uppercase select-none pointer-events-none absolute top-0 left-0 -translate-y-[50%] sm:-translate-y-[55%] md:-translate-y-[60%]">
              EXPLORE
            </h1>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-8">
            <Button onClick={() => setIsTourModalOpen(true)} size="lg">Find My Tour</Button>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm md:text-base flex-wrap text-white">
            <div className="flex items-center gap-0.5 sm:gap-1">
              {[...Array(5)].map((_, i) => (
                <span key={i} className="text-yellow-400 text-sm sm:text-base">★</span>
              ))}
            </div>
            <span className="font-semibold">4.9 Stars on Google</span>
            <span className="text-gray-300">(1,200+ Reviews)</span>
          </div>
        </div>
      </section>

      <TourCategoryModal
        isOpen={isTourModalOpen}
        onClose={() => setIsTourModalOpen(false)}
      />
    </>
  );
}
