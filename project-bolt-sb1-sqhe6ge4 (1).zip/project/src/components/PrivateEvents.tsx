import { Building2, Users, Calendar, Sparkles } from 'lucide-react';
import Button from './Button';

const eventTypes = [
  {
    icon: Sparkles,
    title: 'Bachelorette Parties',
    description: 'Create unforgettable memories'
  },
  {
    icon: Building2,
    title: 'Corporate Events',
    description: 'Team building done right'
  },
  {
    icon: Users,
    title: 'Birthday Celebrations',
    description: 'Party in style'
  },
  {
    icon: Calendar,
    title: 'Special Occasions',
    description: 'Any reason to celebrate'
  }
];

export default function PrivateEvents() {
  return (
    <section id="private-events" className="py-12 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center">
          <div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-4 sm:mb-6">
              Taking Over Kansas City?
              <br />
              <span className="text-orange-600">We'll Handle the Fun</span>
            </h2>

            <p className="text-lg sm:text-xl text-slate-600 mb-6 sm:mb-8 leading-relaxed">
              From corporate team building to bachelorette blowouts, our private tours and party buses are custom-built for your group. You bring the people, we bring the experience.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mb-6 sm:mb-8">
              {eventTypes.map((type) => (
                <div key={type.title} className="flex items-start gap-3">
                  <div className="w-10 sm:w-12 h-10 sm:h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <type.icon className="w-5 sm:w-6 h-5 sm:h-6 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 mb-1 text-sm sm:text-base">{type.title}</h3>
                    <p className="text-xs sm:text-sm text-slate-600">{type.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-slate-50 border-l-4 border-orange-600 p-4 sm:p-6 rounded-lg mb-6 sm:mb-8">
              <p className="text-slate-700 font-medium mb-2 text-sm sm:text-base">
                Groups of 10 or more?
              </p>
              <p className="text-slate-600 text-sm sm:text-base">
                Get custom pricing and a dedicated event coordinator to make your experience seamless.
              </p>
            </div>

            <Button href="#quote" size="lg">Get a Custom Quote</Button>
          </div>

          <div className="relative mt-8 lg:mt-0">
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/1047442/pexels-photo-1047442.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Private party bus"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="absolute -bottom-4 sm:-bottom-6 -left-4 sm:-left-6 bg-white p-4 sm:p-6 rounded-xl shadow-xl max-w-[280px] sm:max-w-xs">
              <p className="text-3xl sm:text-4xl font-bold text-orange-600 mb-1">500+</p>
              <p className="text-slate-700 font-semibold text-sm sm:text-base">Private Events Hosted</p>
              <p className="text-xs sm:text-sm text-slate-600 mt-2">
                Corporate teams, bachelorettes, birthdays & more
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
