import { Calendar, CreditCard, PartyPopper } from 'lucide-react';

const steps = [
  {
    icon: Calendar,
    title: 'Pick Your Tour',
    description: 'Browse our tours and choose the perfect adventure for you'
  },
  {
    icon: CreditCard,
    title: 'Book Online',
    description: 'Secure your spot in 60 seconds with our easy booking system'
  },
  {
    icon: PartyPopper,
    title: 'Show Up & Have Fun',
    description: 'We handle everything else — just bring your good vibes'
  }
];

export default function HowItWorks() {
  return (
    <section className="py-12 sm:py-16 md:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="text-center mb-10 sm:mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-3 sm:mb-4">
            How It Works
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-slate-600 px-4">
            Three simple steps to your next great adventure
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 md:gap-12 relative">
          {steps.map((step, index) => (
            <div key={step.title} className="text-center relative">
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-16 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-orange-500 to-orange-300" />
              )}

              <div className="relative inline-flex items-center justify-center w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 mb-4 sm:mb-5 md:mb-6 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full shadow-xl">
                <div className="absolute -top-2 -right-2 w-8 h-8 sm:w-9 sm:h-9 md:w-10 md:h-10 bg-slate-900 text-white rounded-full flex items-center justify-center font-bold text-base sm:text-lg">
                  {index + 1}
                </div>
                <step.icon className="w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14 text-white" strokeWidth={2} />
              </div>

              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 mb-2 sm:mb-3">{step.title}</h3>
              <p className="text-slate-600 text-sm sm:text-base md:text-lg px-4">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
