import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { FAQSchema } from './SchemaMarkup';

const faqs = [
  {
    question: 'How do I book a tour?',
    answer: 'Booking is easy! Click any "Book Now" button, select your tour, choose your date and party size, and complete payment. You\'ll receive instant confirmation via email.'
  },
  {
    question: 'What\'s included in the tour price?',
    answer: 'All tours include transportation on our comfortable tour bus, an expert guide, and stops at each location. For brewery and BBQ tours, the price includes samples/tastings. Full meals and additional drinks are not included but available for purchase.'
  },
  {
    question: 'What\'s your cancellation policy?',
    answer: 'We offer free cancellation up to 24 hours before your tour start time for a full refund. Cancellations within 24 hours are non-refundable, but you can reschedule for a different date.'
  },
  {
    question: 'Can I bring kids on the tours?',
    answer: 'Our Brewery and Party Bus tours are 21+ only. The BBQ, Sightseeing, Holiday Lights, and Ghost tours are family-friendly and welcome all ages. Kids under 12 receive discounted pricing.'
  },
  {
    question: 'Where do tours depart from?',
    answer: 'Most tours depart from our downtown Kansas City location. Private tours can arrange custom pickup locations. Full address and parking instructions are sent in your confirmation email.'
  },
  {
    question: 'How many people can fit on a tour?',
    answer: 'Our public tours have a maximum of 14 guests for an intimate experience. For private events, we can accommodate groups of 10-40+ guests depending on the bus and package selected.'
  },
  {
    question: 'What if the weather is bad?',
    answer: 'Tours run rain or shine! Our buses are climate-controlled and comfortable year-round. In extreme weather conditions, we\'ll contact you about rescheduling options.'
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-12 sm:py-16 md:py-20 bg-slate-50">
      <FAQSchema faqs={faqs} />
      <div className="max-w-4xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-10 md:mb-12">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-3 sm:mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-slate-600 px-4">
            Everything you need to know before you book
          </p>
        </div>

        <div className="space-y-3 sm:space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-md overflow-hidden transition-all duration-200 hover:shadow-lg"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full px-4 py-4 sm:px-6 sm:py-5 flex items-center justify-between text-left gap-3 sm:gap-4"
              >
                <span className="font-bold text-base sm:text-lg text-slate-900">{faq.question}</span>
                <ChevronDown
                  className={`w-5 h-5 sm:w-6 sm:h-6 text-orange-600 flex-shrink-0 transition-transform duration-200 ${
                    openIndex === index ? 'transform rotate-180' : ''
                  }`}
                />
              </button>

              <div
                className={`overflow-hidden transition-all duration-200 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-4 pb-4 sm:px-6 sm:pb-5 text-sm sm:text-base text-slate-600 leading-relaxed">
                  {faq.answer}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-slate-600 mb-4">Still have questions?</p>
          <a
            href="tel:+18165551234"
            className="text-orange-600 hover:text-orange-700 font-semibold text-lg hover:underline"
          >
            Call us at (816) 555-1234
          </a>
        </div>
      </div>
    </section>
  );
}
