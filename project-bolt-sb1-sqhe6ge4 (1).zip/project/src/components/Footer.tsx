import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div>
            <h3 className="text-2xl font-bold mb-4">Barley Bus</h3>
            <p className="text-slate-400 mb-6 leading-relaxed">
              Kansas City's premier tour experience. Craft beer, BBQ, history, and unforgettable moments since 2016.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-orange-600 rounded-full flex items-center justify-center transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-orange-600 rounded-full flex items-center justify-center transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-orange-600 rounded-full flex items-center justify-center transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4">Our Tours</h4>
            <ul className="space-y-3">
              <li><a href="/tours/brewery" className="text-slate-400 hover:text-orange-500 transition-colors">Brewery Tour</a></li>
              <li><a href="/tours/bbq" className="text-slate-400 hover:text-orange-500 transition-colors">BBQ Tour</a></li>
              <li><a href="/tours/ghost-gangsters" className="text-slate-400 hover:text-orange-500 transition-colors">Ghost & Gangsters</a></li>
              <li><a href="/tours/sightseeing" className="text-slate-400 hover:text-orange-500 transition-colors">City Sightseeing</a></li>
              <li><a href="/tours/holiday-lights" className="text-slate-400 hover:text-orange-500 transition-colors">Holiday Lights</a></li>
              <li><a href="/party-bus" className="text-slate-400 hover:text-orange-500 transition-colors">Party Bus</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4">Company</h4>
            <ul className="space-y-3">
              <li><a href="/about" className="text-slate-400 hover:text-orange-500 transition-colors">About Us</a></li>
              <li><a href="/private-events" className="text-slate-400 hover:text-orange-500 transition-colors">Private Events</a></li>
              <li><a href="/gift-cards" className="text-slate-400 hover:text-orange-500 transition-colors">Gift Cards</a></li>
              <li><a href="/reviews" className="text-slate-400 hover:text-orange-500 transition-colors">Reviews</a></li>
              <li><a href="/blog" className="text-slate-400 hover:text-orange-500 transition-colors">Blog</a></li>
              <li><a href="/contact" className="text-slate-400 hover:text-orange-500 transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4">Contact Us</h4>
            <ul className="space-y-4">
              <li>
                <a href="tel:+18165551234" className="flex items-start gap-3 text-slate-400 hover:text-orange-500 transition-colors group">
                  <Phone className="w-5 h-5 mt-0.5 flex-shrink-0 group-hover:text-orange-500" />
                  <span>(816) 555-1234</span>
                </a>
              </li>
              <li>
                <a href="mailto:hello@barleybus.com" className="flex items-start gap-3 text-slate-400 hover:text-orange-500 transition-colors group">
                  <Mail className="w-5 h-5 mt-0.5 flex-shrink-0 group-hover:text-orange-500" />
                  <span>hello@barleybus.com</span>
                </a>
              </li>
              <li className="flex items-start gap-3 text-slate-400">
                <MapPin className="w-5 h-5 mt-0.5 flex-shrink-0" />
                <span>
                  123 Main Street<br />
                  Kansas City, MO 64105
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-400 text-sm">
              © 2024 Barley Bus. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="/privacy" className="text-slate-400 hover:text-orange-500 transition-colors">Privacy Policy</a>
              <a href="/terms" className="text-slate-400 hover:text-orange-500 transition-colors">Terms of Service</a>
              <a href="/cancellation" className="text-slate-400 hover:text-orange-500 transition-colors">Cancellation Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
