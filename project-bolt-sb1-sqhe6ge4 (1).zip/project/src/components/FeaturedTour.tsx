import { Clock, Users, Star } from 'lucide-react';
import Button from './Button';

export default function FeaturedTour() {
  return (
    <section className="py-12 sm:py-16 md:py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="relative rounded-xl sm:rounded-2xl overflow-hidden shadow-2xl">
          <div className="absolute inset-0">
            <img
              src="https://images.pexels.com/photos/1089930/pexels-photo-1089930.jpeg?auto=compress&cs=tinysrgb&w=1920"
              alt="Kansas City Brewery Tour"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-transparent" />
          </div>

          <div className="relative z-10 px-4 py-8 sm:px-6 sm:py-12 md:px-12 md:py-16 lg:py-24 lg:px-16 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 sm:gap-2 bg-orange-600 text-white px-3 py-1.5 sm:px-4 sm:py-2 rounded-full mb-4 sm:mb-6 font-semibold text-xs sm:text-sm">
              <Star className="w-3 h-3 sm:w-4 sm:h-4 fill-white" />
              Most Popular Tour
            </div>

            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-3 sm:mb-4">
              Kansas City Brewery Tour
            </h2>

            <p className="text-sm sm:text-base md:text-lg lg:text-xl text-slate-200 mb-4 sm:mb-6 leading-relaxed">
              Discover why Kansas City is a craft beer destination. Visit 3-4 award-winning breweries, taste exclusive pours, and learn from expert guides who know the local beer scene inside out.
            </p>

            <div className="flex flex-wrap gap-3 sm:gap-4 md:gap-6 mb-6 sm:mb-8 text-white text-sm sm:text-base">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-orange-400" />
                <span className="font-medium">3.5 hours</span>
              </div>
              <div className="flex items-center gap-1.5 sm:gap-2">
                <Users className="w-4 h-4 sm:w-5 sm:h-5 text-orange-400" />
                <span className="font-medium">Small groups (max 14)</span>
              </div>
              <div className="flex items-center gap-1.5 sm:gap-2">
                <Star className="w-4 h-4 sm:w-5 sm:h-5 text-orange-400 fill-orange-400" />
                <span className="font-medium">4.9/5 rating</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 items-start">
              <div className="bg-white px-4 py-2 sm:px-6 sm:py-3 rounded-lg">
                <span className="text-xs sm:text-sm text-slate-600">From</span>
                <p className="text-2xl sm:text-3xl font-bold text-orange-600">$75</p>
                <span className="text-xs text-slate-600">per person</span>
              </div>
              <Button href="/tours/brewery" size="lg">Book This Tour</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
