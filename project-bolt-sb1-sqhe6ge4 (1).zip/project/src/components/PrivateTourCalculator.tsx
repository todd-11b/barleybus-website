import { useState } from 'react';
import { Check, Plus, Minus } from 'lucide-react';

type ExperienceType = 'bus-rental' | 'private-tour' | 'custom' | null;
type VehicleSize = '14-passenger' | '20-passenger' | null;
type TourCategory = 'drink' | 'food' | 'sightseeing' | null;

interface TourOption {
  name: string;
  rate: number;
  category: 'drink' | 'food' | 'sightseeing';
}

const tourOptions: TourOption[] = [
  { name: 'Brewery', rate: 99, category: 'drink' },
  { name: 'Winery', rate: 99, category: 'drink' },
  { name: 'Distillery', rate: 99, category: 'drink' },
  { name: 'Mix (Brewery/Winery/Distillery)', rate: 99, category: 'drink' },
  { name: 'BBQ', rate: 125, category: 'food' },
  { name: 'Tacos & Margs', rate: 125, category: 'food' },
  { name: 'Ghost & Gangsters', rate: 60, category: 'sightseeing' },
  { name: 'KC Sightseeing', rate: 60, category: 'sightseeing' },
  { name: 'Instagram', rate: 60, category: 'sightseeing' },
];

export default function PrivateTourCalculator() {
  const [experienceType, setExperienceType] = useState<ExperienceType>(null);
  const [vehicleSize, setVehicleSize] = useState<VehicleSize>(null);
  const [hours, setHours] = useState(4);
  const [tourCategory, setTourCategory] = useState<TourCategory>(null);
  const [selectedTour, setSelectedTour] = useState<TourOption | null>(null);
  const [guestCount, setGuestCount] = useState(10);

  const calculatePrice = () => {
    if (!experienceType) return null;

    if (experienceType === 'bus-rental' && vehicleSize) {
      const weekdayRate = vehicleSize === '14-passenger' ? 150 : 175;
      const weekendRate = vehicleSize === '14-passenger' ? 175 : 200;
      const minTotal = weekdayRate * hours;
      const maxTotal = weekendRate * hours;
      return {
        type: 'range',
        min: minTotal,
        max: maxTotal,
        label: 'Estimated range',
        subtext: 'Varies by day of week',
      };
    }

    if (experienceType === 'private-tour' && selectedTour) {
      const total = selectedTour.rate * Math.max(guestCount, 10);
      return {
        type: 'total',
        amount: total,
        label: 'Pricing starts at',
        subtext: `$${selectedTour.rate}/person × ${Math.max(guestCount, 10)} guests`,
      };
    }

    if (experienceType === 'custom') {
      const rate = 150;
      const total = rate * Math.max(guestCount, 10);
      return {
        type: 'starting',
        amount: total,
        label: 'Starting at',
        subtext: `$${rate}/person × ${Math.max(guestCount, 10)} guests · final price based on your needs`,
      };
    }

    return null;
  };

  const priceData = calculatePrice();
  const showMinimumWarning =
    (experienceType === 'private-tour' || experienceType === 'custom') && guestCount < 10;

  const getButtonText = () => {
    if (experienceType === 'custom') return 'Tell us what you need';
    return 'Lock in your date';
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white rounded-2xl shadow-2xl overflow-hidden border border-gray-200">
      <div className="bg-gray-900 px-6 py-6 rounded-t-2xl">
        <div className="text-sm font-medium text-amber-400 mb-2">Barley Bus</div>
        <h2 className="text-2xl font-bold text-white">Plan your group. See your price.</h2>
      </div>

      <div className="bg-white px-6 py-6">
        <h3 className="text-base font-semibold text-gray-900 mb-4">What kind of experience?</h3>
        <div className="space-y-3 mb-6">
          <button
            onClick={() => {
              setExperienceType('bus-rental');
              setSelectedTour(null);
            }}
            className={`w-full text-left px-4 py-4 rounded-xl border-2 transition-all ${
              experienceType === 'bus-rental'
                ? 'border-amber-500 bg-amber-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="font-semibold text-gray-900 mb-1">Bus rental</div>
                <div className="text-sm text-gray-600">You plan the stops, we drive</div>
              </div>
              {experienceType === 'bus-rental' && (
                <Check className="w-5 h-5 text-amber-600 flex-shrink-0" />
              )}
            </div>
          </button>

          <button
            onClick={() => {
              setExperienceType('private-tour');
              setVehicleSize(null);
            }}
            className={`w-full text-left px-4 py-4 rounded-xl border-2 transition-all ${
              experienceType === 'private-tour'
                ? 'border-amber-500 bg-amber-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="font-semibold text-gray-900 mb-1">Private tour</div>
                <div className="text-sm text-gray-600">We handle everything</div>
              </div>
              {experienceType === 'private-tour' && (
                <Check className="w-5 h-5 text-amber-600 flex-shrink-0" />
              )}
            </div>
          </button>

          <button
            onClick={() => {
              setExperienceType('custom');
              setVehicleSize(null);
            }}
            className={`w-full text-left px-4 py-4 rounded-xl border-2 transition-all ${
              experienceType === 'custom'
                ? 'border-amber-500 bg-amber-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="font-semibold text-gray-900 mb-1">Custom experience</div>
                <div className="text-sm text-gray-600">Built around your group</div>
              </div>
              {experienceType === 'custom' && (
                <Check className="w-5 h-5 text-amber-600 flex-shrink-0" />
              )}
            </div>
          </button>
        </div>

        {experienceType === 'bus-rental' && (
          <div className="border-t border-gray-200 pt-6 mb-6">
            <div className="mb-4">
              <div className="text-sm font-medium text-gray-700 mb-3">Vehicle size</div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setVehicleSize('14-passenger')}
                  className={`px-4 py-3 rounded-lg border-2 text-left transition-all ${
                    vehicleSize === '14-passenger'
                      ? 'border-amber-500 bg-amber-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-semibold text-gray-900 text-sm mb-0.5">14-passenger</div>
                  <div className="text-xs text-gray-600">from $150/hr</div>
                </button>
                <button
                  onClick={() => setVehicleSize('20-passenger')}
                  className={`px-4 py-3 rounded-lg border-2 text-left transition-all ${
                    vehicleSize === '20-passenger'
                      ? 'border-amber-500 bg-amber-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-semibold text-gray-900 text-sm mb-0.5">20-passenger</div>
                  <div className="text-xs text-gray-600">from $175/hr</div>
                </button>
              </div>
            </div>

            {vehicleSize && (
              <div>
                <div className="text-sm font-medium text-gray-700 mb-3">
                  Hours <span className="text-gray-500 font-normal">(4 minimum)</span>
                </div>
                <input
                  type="range"
                  min="4"
                  max="12"
                  value={hours}
                  onChange={(e) => setHours(Number(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
                <div className="flex justify-between text-sm text-gray-600 mt-2">
                  <span>4 hrs</span>
                  <span className="font-semibold text-gray-900">{hours} hours</span>
                  <span>12 hrs</span>
                </div>
              </div>
            )}
          </div>
        )}

        {(experienceType === 'private-tour' || experienceType === 'custom') && (
          <div className="border-t border-gray-200 pt-6 mb-6">
            <div className="text-sm font-medium text-gray-700 mb-3">Tour category</div>
            <div className="grid grid-cols-3 gap-3 mb-4">
              <button
                onClick={() => {
                  setTourCategory('drink');
                  setSelectedTour(null);
                }}
                className={`px-4 py-3 rounded-lg border-2 text-center transition-all ${
                  tourCategory === 'drink'
                    ? 'border-amber-500 bg-amber-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="font-semibold text-gray-900 text-sm">Drink</div>
              </button>
              <button
                onClick={() => {
                  setTourCategory('food');
                  setSelectedTour(null);
                }}
                className={`px-4 py-3 rounded-lg border-2 text-center transition-all ${
                  tourCategory === 'food'
                    ? 'border-amber-500 bg-amber-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="font-semibold text-gray-900 text-sm">Food</div>
              </button>
              <button
                onClick={() => {
                  setTourCategory('sightseeing');
                  setSelectedTour(null);
                }}
                className={`px-4 py-3 rounded-lg border-2 text-center transition-all ${
                  tourCategory === 'sightseeing'
                    ? 'border-amber-500 bg-amber-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="font-semibold text-gray-900 text-sm">Sightseeing</div>
              </button>
            </div>

            {tourCategory && (
              <>
                <div className="text-sm font-medium text-gray-700 mb-3">Select your tour</div>
                <div className="space-y-2">
                  {tourOptions
                    .filter((tour) => tour.category === tourCategory)
                    .map((tour) => (
                      <button
                        key={tour.name}
                        onClick={() => setSelectedTour(tour)}
                        className={`w-full flex items-center justify-between px-4 py-3 rounded-lg border-2 text-left transition-all ${
                          selectedTour?.name === tour.name
                            ? 'border-amber-500 bg-amber-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <span className="text-sm font-medium text-gray-900">{tour.name}</span>
                        <span className="text-sm font-semibold text-gray-900">${tour.rate}</span>
                      </button>
                    ))}
                </div>
              </>
            )}
          </div>
        )}

        <div className="mb-6">
          <div className="text-sm font-medium text-gray-700 mb-3">How many guests?</div>
          <div className="flex items-center justify-center gap-6">
            <button
              onClick={() => setGuestCount(Math.max(1, guestCount - 1))}
              className="w-10 h-10 rounded-full border-2 border-gray-300 hover:border-amber-500 flex items-center justify-center transition-all hover:bg-amber-50"
            >
              <Minus className="w-5 h-5 text-gray-600" />
            </button>
            <div className="text-4xl font-bold text-gray-900 min-w-[80px] text-center">
              {guestCount}
            </div>
            <button
              onClick={() => setGuestCount(guestCount + 1)}
              className="w-10 h-10 rounded-full border-2 border-gray-300 hover:border-amber-500 flex items-center justify-center transition-all hover:bg-amber-50"
            >
              <Plus className="w-5 h-5 text-gray-600" />
            </button>
          </div>
          {showMinimumWarning && (
            <div className="text-center text-sm text-amber-700 mt-2">10 guest minimum</div>
          )}
        </div>
      </div>

      <div className="bg-gray-50 px-6 py-6">
        <div className="mb-6">
          {priceData ? (
            <>
              <div className="text-sm text-gray-600 mb-2">{priceData.label}</div>
              {priceData.type === 'range' ? (
                <div className="text-4xl font-bold text-emerald-600 mb-2">
                  ${priceData.min.toLocaleString()} – ${priceData.max.toLocaleString()}
                </div>
              ) : (
                <div className="text-4xl font-bold text-emerald-600 mb-2">
                  ${priceData.amount.toLocaleString()}
                </div>
              )}
              <div className="text-sm text-gray-600">{priceData.subtext}</div>
            </>
          ) : (
            <>
              <div className="text-sm text-gray-600 mb-2">Your price</div>
              <div className="text-4xl font-bold text-gray-300 mb-2">$0</div>
              <div className="text-sm text-gray-500">Make your selections above</div>
            </>
          )}
        </div>
      </div>

      <div className="bg-white px-6 py-6 rounded-b-2xl border-t border-gray-200">
        <button className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-4 px-6 rounded-full transition-all shadow-lg hover:shadow-xl">
          {getButtonText()}
        </button>
      </div>
    </div>
  );
}
