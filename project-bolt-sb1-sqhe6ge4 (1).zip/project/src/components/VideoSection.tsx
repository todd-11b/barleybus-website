import { Play } from 'lucide-react';

export default function VideoSection() {
  return (
    <section className="py-12 sm:py-16 md:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-10 md:mb-12">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-3 sm:mb-4">
            See The Experience
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-slate-600 px-4">
            Real guests, real moments, real fun
          </p>
        </div>

        <div className="relative rounded-xl sm:rounded-2xl overflow-hidden shadow-2xl group cursor-pointer max-w-5xl mx-auto">
          <div className="aspect-video bg-slate-900 min-h-[200px] sm:min-h-[250px] md:min-h-0">
            <img
              src="https://images.pexels.com/photos/1267697/pexels-photo-1267697.jpeg?auto=compress&cs=tinysrgb&w=1920"
              alt="Barley Bus Tour Video"
              className="w-full h-full object-cover opacity-80 group-hover:opacity-90 transition-opacity"
            />
          </div>

          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 bg-orange-600 rounded-full flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
              <Play className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 text-white ml-0.5 sm:ml-1" fill="white" />
            </div>
          </div>

          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 sm:p-6 md:p-8">
            <p className="text-white text-sm sm:text-base md:text-lg font-semibold">
              Watch: A Day on the Barley Bus
            </p>
            <p className="text-slate-300 text-xs sm:text-sm">2:15 minutes</p>
          </div>
        </div>
      </div>
    </section>
  );
}
