import TourCard from './TourCard';

const tours = [
  {
    title: 'Brewery Tour',
    description: 'Hop on board for Kansas City\'s ultimate craft beer experience. Visit 3-4 top breweries with expert guides.',
    priceFrom: 75,
    image: 'https://images.pexels.com/photos/1089930/pexels-photo-1089930.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.9,
    href: '/tour/brewery-tour'
  },
  {
    title: 'BBQ Tour',
    description: 'Taste the legendary KC BBQ at the city\'s most iconic joints. Come hungry, leave happy.',
    priceFrom: 85,
    image: 'https://images.pexels.com/photos/1109197/pexels-photo-1109197.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 5.0,
    href: '/tour/bbq-tour'
  },
  {
    title: 'Ghost & Gangsters',
    description: 'Explore Kansas City\'s haunted history and notorious mob past on this spine-tingling tour.',
    priceFrom: 65,
    image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.8,
    href: '/tour/ghost-gangsters'
  },
  {
    title: 'City Sightseeing',
    description: 'See all of Kansas City\'s must-visit landmarks, hidden gems, and photo-worthy spots.',
    priceFrom: 55,
    image: 'https://images.pexels.com/photos/466685/pexels-photo-466685.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.9,
    href: '/tour/sightseeing'
  },
  {
    title: 'Holiday Lights',
    description: 'Experience the magic of Kansas City\'s spectacular holiday light displays in festive comfort.',
    priceFrom: 60,
    image: 'https://images.pexels.com/photos/1708801/pexels-photo-1708801.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 5.0,
    href: '/tour/holiday-lights'
  },
  {
    title: 'Party Bus',
    description: 'Your private party on wheels. Perfect for birthdays, bachelorettes, and unforgettable celebrations.',
    priceFrom: 95,
    image: 'https://images.pexels.com/photos/1047442/pexels-photo-1047442.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.9,
    href: '/tour/party-bus'
  }
];

export default function TourGrid() {
  return (
    <section id="tours" className="py-12 sm:py-16 md:py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="text-center mb-10 sm:mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-3 sm:mb-4">
            Choose Your Adventure
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-slate-600 max-w-2xl mx-auto px-4">
            From craft beer to BBQ, ghosts to holiday lights — we've got the perfect tour for every occasion
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 md:gap-8">
          {tours.map((tour) => (
            <TourCard key={tour.title} {...tour} />
          ))}
        </div>
      </div>
    </section>
  );
}
