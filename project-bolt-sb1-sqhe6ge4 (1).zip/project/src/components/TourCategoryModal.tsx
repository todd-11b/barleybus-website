import { X, Beer, UtensilsCrossed, Camera, Users, PartyPopper, ChevronDown } from 'lucide-react';
import { useEffect, useState } from 'react';

interface TourCategoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const tourCategories = [
  {
    id: 'drink',
    title: 'Drink Tours',
    icon: Beer,
    image: '/sightseeing.webp',
    description: 'Explore Kansas City breweries and distilleries'
  },
  {
    id: 'food',
    title: 'Food Tours',
    icon: UtensilsCrossed,
    image: '/sightseeing.webp',
    description: 'Taste the best of KC cuisine'
  },
  {
    id: 'sightseeing',
    title: 'Sightseeing Tours',
    icon: Camera,
    image: '/sightseeing.webp',
    description: 'Discover Kansas City landmarks'
  },
  {
    id: 'private',
    title: 'Private Tours',
    icon: Users,
    image: '/sightseeing.webp',
    description: 'Custom experiences for your group'
  },
  {
    id: 'party',
    title: 'Party Bus',
    icon: PartyPopper,
    image: '/sightseeing.webp',
    description: 'Celebrate in style on the move'
  }
];

export default function TourCategoryModal({ isOpen, onClose }: TourCategoryModalProps) {
  const [showScrollIndicator, setShowScrollIndicator] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    const checkScroll = () => {
      const modal = document.getElementById('tour-modal-content');
      if (modal) {
        const hasScroll = modal.scrollHeight > modal.clientHeight;
        const isAtBottom = modal.scrollHeight - modal.scrollTop <= modal.clientHeight + 10;
        setShowScrollIndicator(hasScroll && !isAtBottom);
      }
    };

    const modal = document.getElementById('tour-modal-content');
    if (modal) {
      checkScroll();
      modal.addEventListener('scroll', checkScroll);
      window.addEventListener('resize', checkScroll);

      return () => {
        modal.removeEventListener('scroll', checkScroll);
        window.removeEventListener('resize', checkScroll);
      };
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      <div className="relative bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-4 sm:px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Find Your Tour</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            aria-label="Close modal"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div id="tour-modal-content" className="overflow-y-auto flex-1 p-4 sm:p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            {tourCategories.map((category) => {
              const Icon = category.icon;
              return (
                <button
                  key={category.id}
                  className="group relative overflow-hidden rounded-xl border-2 border-gray-200 hover:border-orange-600 transition-all duration-300 hover:shadow-lg bg-white"
                >
                  <div className="aspect-[4/3] sm:aspect-[4/3] relative overflow-hidden">
                    <img
                      src={category.image}
                      alt={category.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-black/20" />
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-3 sm:p-4">
                      <div className="bg-orange-600 p-2 sm:p-3 rounded-full mb-2 sm:mb-3 group-hover:scale-110 transition-transform duration-300">
                        <Icon className="w-5 h-5 sm:w-8 sm:h-8" />
                      </div>
                      <h3 className="text-base sm:text-xl font-bold mb-1 sm:mb-2 text-center">{category.title}</h3>
                      <p className="text-xs sm:text-sm text-white/90 text-center line-clamp-2">{category.description}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {showScrollIndicator && (
          <div className="absolute bottom-0 left-0 right-0 pointer-events-none">
            <div className="bg-gradient-to-t from-white via-white to-transparent pt-12 pb-4 flex justify-center">
              <div className="animate-bounce bg-orange-600 rounded-full p-2 shadow-lg">
                <ChevronDown className="w-5 h-5 text-white" />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
