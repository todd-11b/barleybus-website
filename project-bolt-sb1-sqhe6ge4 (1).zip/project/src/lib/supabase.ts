import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Tour = {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  duration_hours: number;
  price_from: number;
  max_capacity: number;
  tour_type: string;
  featured: boolean;
  active: boolean;
  created_at: string;
  updated_at: string;
};

export type Review = {
  id: string;
  tour_id: string | null;
  guest_name: string;
  rating: number;
  review_text: string;
  review_date: string;
  verified: boolean;
  created_at: string;
};

export type FAQ = {
  id: string;
  question: string;
  answer: string;
  category: string;
  sort_order: number;
  active: boolean;
};

export type PrivateEventInquiry = {
  name: string;
  email: string;
  phone: string;
  event_date?: string;
  guest_count?: number;
  event_type: string;
  message: string;
};

export type TourItineraryStop = {
  id: string;
  tour_id: string;
  stop_number: number;
  name: string;
  description: string;
  duration_minutes: number;
};

export type TourInclusion = {
  id: string;
  tour_id: string;
  item: string;
  included: boolean;
  sort_order: number;
};

export type TourPhoto = {
  id: string;
  tour_id: string;
  url: string;
  caption?: string;
  is_hero: boolean;
  sort_order: number;
};

export type UGCPhoto = {
  id: string;
  instagram_url?: string;
  photo_url: string;
  caption?: string;
  guest_name?: string;
  tour_id?: string;
  featured: boolean;
  created_at: string;
};
