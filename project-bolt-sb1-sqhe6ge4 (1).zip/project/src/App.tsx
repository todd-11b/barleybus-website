import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Home from './pages/Home';
import TourDetails from './pages/TourDetails';
import Packages from './pages/Packages';
import About from './pages/About';
import PrivateEventsPage from './pages/PrivateEventsPage';
import PartyBus from './pages/PartyBus';
import Gallery from './pages/Gallery';
import BreweryTours from './pages/BreweryTours';
import DistilleryTours from './pages/DistilleryTours';
import WineryTours from './pages/WineryTours';
import FoodTours from './pages/FoodTours';
import SightseeingTours from './pages/SightseeingTours';
import Reviews from './pages/Reviews';
import Stops from './pages/Stops';
import Contact from './pages/Contact';
import GiftCertificates from './pages/GiftCertificates';
import GroupTours from './pages/GroupTours';
import BusRental from './pages/BusRental';
import Download from './pages/Download';

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

function App() {
  return (
    <Router>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/home" element={<Home />} />
        <Route path="/tours/:slug" element={<TourDetails />} />
        <Route path="/tour/:id" element={<TourDetails />} />
        <Route path="/packages" element={<Packages />} />
        <Route path="/kc-tours" element={<Packages />} />
        <Route path="/about" element={<About />} />
        <Route path="/private-events" element={<PrivateEventsPage />} />
        <Route path="/party-bus" element={<PartyBus />} />
        <Route path="/gallery" element={<Gallery />} />

        {/* Tour Category Pages */}
        <Route path="/brewery-tours" element={<BreweryTours />} />
        <Route path="/distillery-tours" element={<DistilleryTours />} />
        <Route path="/winery-tours" element={<WineryTours />} />
        <Route path="/food-tours" element={<FoodTours />} />
        <Route path="/kc-sightseeing-tours" element={<SightseeingTours />} />

        {/* Core Pages */}
        <Route path="/reviews" element={<Reviews />} />
        <Route path="/stops" element={<Stops />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/gift-certificates" element={<GiftCertificates />} />
        <Route path="/group-tours" element={<GroupTours />} />
        <Route path="/kc-bus-rental" element={<BusRental />} />
        <Route path="/download" element={<Download />} />
      </Routes>
    </Router>
  );
}

export default App;
