import { Bus, Users, Music, Sparkles, Calendar, Clock, Phone } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Button from '../components/Button';

export default function PartyBus() {
  const features = [
    {
      icon: Bus,
      title: 'Premium Fleet',
      description: 'Modern, well-maintained party buses with luxury amenities'
    },
    {
      icon: Users,
      title: 'Any Group Size',
      description: 'Accommodate groups from 15 to 40+ passengers'
    },
    {
      icon: Music,
      title: 'Sound Systems',
      description: 'State-of-the-art audio with Bluetooth connectivity'
    },
    {
      icon: Sparkles,
      title: 'LED Lighting',
      description: 'Custom lighting to set the perfect party atmosphere'
    }
  ];

  const occasions = [
    'Bachelor & Bachelorette Parties',
    'Birthday Celebrations',
    'Corporate Events',
    'Sporting Events',
    'Concerts & Shows',
    'Wedding Transportation',
    'Prom & Homecoming',
    'Wine Tours',
    'Bar Crawls',
    'Any Special Occasion'
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="relative min-h-[480px] lg:min-h-[640px] 2xl:min-h-[920px] text-center bg-no-repeat bg-center bg-cover before:absolute before:inset-0 before:bg-gradient-to-t before:from-black/60 before:to-black/20"
        style={{backgroundImage: `url('/Barley-Bus-home-banner.jpg')`}}>
        <div className="container relative z-10 h-full mx-auto px-4">
          <div className="text-center py-10 sm:py-15 flex flex-col items-center justify-center min-h-[480px] lg:min-h-[640px] 2xl:min-h-[920px]">
            <h1 className="text-4xl sm:text-6xl lg:text-8xl xl:text-[10rem] uppercase text-white leading-tight mb-6">
              Party Bus
            </h1>
            <p className="text-xl sm:text-2xl lg:text-3xl text-white max-w-3xl mb-8">
              Kansas City's Premier Party Bus Rentals
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button href="https://book.barleybus.com" size="lg">Book Now</Button>
              <Button href="tel:+18165550100" size="lg" variant="secondary">
                Call Us
              </Button>
            </div>
          </div>
        </div>
      </div>

      <section className="py-12 sm:py-20 lg:py-25">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-medium mb-6">
              The Ultimate Party Experience on Wheels
            </h2>
            <p className="text-lg sm:text-xl text-gray-700">
              Whether you're celebrating a bachelor party, birthday, corporate event, or just a night out with friends,
              our party buses provide the perfect combination of luxury, entertainment, and safety. Travel together in
              style while enjoying premium amenities and professional service.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {features.map((feature, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-amber-500 mb-4">
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-20 lg:py-25 bg-stone-100">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-medium mb-8 text-center">
              Perfect For Any Occasion
            </h2>
            <div className="grid sm:grid-cols-2 gap-4">
              {occasions.map((occasion, index) => (
                <div key={index} className="flex items-center gap-3 bg-white rounded-lg px-6 py-4">
                  <div className="w-2 h-2 rounded-full bg-amber-500 flex-shrink-0"></div>
                  <span className="text-lg font-medium">{occasion}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-20 lg:py-25">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-medium mb-12 text-center">
              Why Choose Barley Bus?
            </h2>

            <div className="space-y-8">
              <div className="bg-stone-100 rounded-2xl p-8">
                <h3 className="text-2xl font-semibold mb-4">Safety First</h3>
                <p className="text-lg text-gray-700">
                  All our vehicles are professionally maintained and operated by experienced, licensed drivers.
                  Enjoy your celebration while we handle the transportation safely and responsibly.
                </p>
              </div>

              <div className="bg-stone-100 rounded-2xl p-8">
                <h3 className="text-2xl font-semibold mb-4">Luxury Amenities</h3>
                <p className="text-lg text-gray-700">
                  Our party buses feature premium sound systems, LED lighting, comfortable seating, climate control,
                  and more. Everything you need to keep the party going between destinations.
                </p>
              </div>

              <div className="bg-stone-100 rounded-2xl p-8">
                <h3 className="text-2xl font-semibold mb-4">Flexible Packages</h3>
                <p className="text-lg text-gray-700">
                  Whether you need a few hours or an all-day rental, we offer flexible packages tailored to your
                  event. Custom itineraries available to match your exact needs.
                </p>
              </div>

              <div className="bg-stone-100 rounded-2xl p-8">
                <h3 className="text-2xl font-semibold mb-4">Local Expertise</h3>
                <p className="text-lg text-gray-700">
                  As Kansas City's premier party bus service, we know the best spots and can help plan your perfect
                  route through the city's top entertainment districts.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-20 lg:py-25 bg-black text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-medium mb-6">
            Ready to Book Your Party Bus?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Contact us today to check availability and get a custom quote for your event.
            Our team is ready to make your celebration unforgettable.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button href="https://book.barleybus.com" size="lg">Book Online</Button>
            <Button href="tel:+18165550100" size="lg" variant="secondary">
              Call (816) 555-0100
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
