import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import StickyBookButton from '../components/StickyBookButton';

export default function About() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <StickyBookButton />

      {/* Hero Section */}
      <section className="pt-24 sm:pt-28 md:pt-32 pb-12 sm:pb-16 md:pb-20 px-3 sm:px-4 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-6 sm:gap-8 md:gap-12 items-start">
            <div>
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-slate-900 mb-4 sm:mb-6 leading-tight">
                Tours designed to create unforgettable memories.
              </h1>
              <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
                With Benefits from web design agency, Earn rewards & Score discounts on purchases. For yourself and your customers.
              </p>
            </div>
            <div className="bg-slate-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 md:p-8">
              <div className="flex items-center gap-3 sm:gap-4 mb-4 sm:mb-6">
                <div className="flex -space-x-2 sm:-space-x-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-orange-400 border-2 border-white"></div>
                  <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-orange-500 border-2 border-white"></div>
                  <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-orange-600 border-2 border-white"></div>
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-black text-slate-900">2.5k clients</div>
                  <div className="text-xs sm:text-sm text-slate-600">in the world</div>
                </div>
              </div>
              <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
                With Benefits from web design agency, Earn rewards & Score discounts on purchases. For yourself and your customers.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Full Width Image */}
      <section className="px-3 sm:px-4 lg:px-8 pb-12 sm:pb-16 md:pb-20">
        <div className="max-w-7xl mx-auto">
          <div className="relative h-[250px] sm:h-[350px] md:h-[500px] rounded-xl sm:rounded-2xl overflow-hidden">
            <img
              src="https://images.pexels.com/photos/1010657/pexels-photo-1010657.jpeg?auto=compress&cs=tinysrgb&w=1600"
              alt="Kansas City Skyline"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Popular Packages */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-black text-slate-900 mb-12">
            POPULAR<br />PACKAGES
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: 'BREWERY CRAWL TOUR.',
                duration: '4 HOURS / 3 STOPS',
                price: '$79',
                oldPrice: '$99',
                image: 'https://images.pexels.com/photos/1269025/pexels-photo-1269025.jpeg?auto=compress&cs=tinysrgb&w=800'
              },
              {
                title: 'BBQ & BOURBON TOUR.',
                duration: '5 HOURS / 4 STOPS',
                price: '$89',
                oldPrice: '$109',
                image: 'https://images.pexels.com/photos/1552635/pexels-photo-1552635.jpeg?auto=compress&cs=tinysrgb&w=800'
              },
              {
                title: 'BACHELORETTE PARTY PACKAGE.',
                duration: '6 HOURS / CUSTOM',
                price: '$99',
                oldPrice: '$129',
                image: 'https://images.pexels.com/photos/1267696/pexels-photo-1267696.jpeg?auto=compress&cs=tinysrgb&w=800'
              }
            ].map((pkg, idx) => (
              <div key={idx} className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                <div className="relative h-48">
                  <img src={pkg.image} alt={pkg.title} className="w-full h-full object-cover" />
                  <div className="absolute top-4 left-4 bg-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                    Kansas City
                  </div>
                </div>
                <div className="p-6">
                  <div className="text-xs font-semibold text-slate-500 mb-2">{pkg.duration}</div>
                  <h3 className="text-xl font-black text-slate-900 mb-3">{pkg.title}</h3>
                  <div className="flex items-center gap-1 mb-4">
                    <div className="flex text-orange-500">
                      {[...Array(5)].map((_, i) => (
                        <span key={i}>★</span>
                      ))}
                    </div>
                    <span className="text-sm text-slate-600 ml-2">18 Reviews</span>
                  </div>
                  <p className="text-sm text-slate-600 mb-6">
                    Experience the best of Kansas City in one unforgettable tour.
                  </p>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-3xl font-black text-slate-900">{pkg.price}</span>
                      <span className="text-sm text-slate-400 line-through ml-2">{pkg.oldPrice}</span>
                    </div>
                    <button className="bg-orange-500 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-orange-600 transition-colors">
                      →
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-12 text-center">
            <button className="text-2xl font-black text-slate-900 hover:text-orange-600 transition-colors">
              View All Packages
            </button>
          </div>
        </div>
      </section>

      {/* Mission/Vision Split */}
      <section className="relative h-[500px] overflow-hidden">
        <div className="absolute inset-0 grid md:grid-cols-2">
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/2166559/pexels-photo-2166559.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Mission"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <h2 className="text-6xl md:text-7xl font-black text-white tracking-wider opacity-40">MISSION</h2>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/2166711/pexels-photo-2166711.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Vision"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-slate-900/70 flex items-center justify-center px-8">
              <div className="max-w-md text-white">
                <h3 className="text-4xl font-black mb-4">Vision</h3>
                <p className="text-slate-300 leading-relaxed">
                  At Barley Bus, our mission is simple: to turn your ideas into impactful realities. We are dedicated to providing innovative, creative solutions that drive growth, elevate brands, and make a lasting impact.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* IMAGINE Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-5xl md:text-6xl font-black text-slate-900 mb-6">
                IMAGINE
              </h2>
              <div className="w-16 h-1 bg-orange-600 mb-8"></div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">
                Barley Bus helps you create the perfect Bachelorette Party.
              </h3>
              <p className="text-slate-600 leading-relaxed mb-8">
                Begin your bachelorette party planning by selecting from our pre-designed packages or let us help you customize a unique celebration that fits your bride perfectly.
              </p>
              <button className="border-2 border-slate-900 text-slate-900 px-8 py-3 font-bold hover:bg-slate-900 hover:text-white transition-colors">
                LEARN MORE
              </button>
            </div>
            <div>
              <img
                src="https://images.pexels.com/photos/1015568/pexels-photo-1015568.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Kansas City Love"
                className="w-full h-auto rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className="order-2 md:order-1">
              <img
                src="https://images.pexels.com/photos/5638266/pexels-photo-5638266.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Planning"
                className="w-full h-auto rounded-lg shadow-xl"
              />
            </div>
            <div className="order-1 md:order-2">
              <h2 className="text-5xl md:text-6xl font-black text-slate-900 mb-6">
                PLAN
              </h2>
              <div className="w-16 h-1 bg-orange-600 mb-8"></div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">
                We can take the wheel on planning.
              </h3>
              <p className="text-slate-600 leading-relaxed mb-8">
                Let us take care of everything, from choosing the best spots to organizing transportation, dining, and fun activities, so you can just relax and have fun. Or, if you'd like to be more hands-on, we're here to help with planning and coordination.
              </p>
              <button className="border-2 border-slate-900 text-slate-900 px-8 py-3 font-bold hover:bg-slate-900 hover:text-white transition-colors">
                LEARN MORE
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-5xl md:text-6xl font-black text-slate-900 mb-6">
                CELEBRATE
              </h2>
              <div className="w-16 h-1 bg-orange-600 mb-8"></div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">
                Kansas City's best experiences, all in one tour.
              </h3>
              <p className="text-slate-600 leading-relaxed mb-8">
                From award-winning breweries to world-famous BBQ, from historic landmarks to hidden gems, we bring together the very best of Kansas City in one unforgettable experience. Sit back, relax, and let us show you the city.
              </p>
              <button className="border-2 border-slate-900 text-slate-900 px-8 py-3 font-bold hover:bg-slate-900 hover:text-white transition-colors">
                SEE ALL TOURS
              </button>
            </div>
            <div>
              <img
                src="https://images.pexels.com/photos/1267696/pexels-photo-1267696.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Celebrate"
                className="w-full h-auto rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className="order-2 md:order-1">
              <img
                src="https://images.pexels.com/photos/1739942/pexels-photo-1739942.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Our Story"
                className="w-full h-auto rounded-lg shadow-xl"
              />
            </div>
            <div className="order-1 md:order-2">
              <h2 className="text-5xl md:text-6xl font-black text-slate-900 mb-6">
                OUR STORY
              </h2>
              <div className="w-16 h-1 bg-orange-600 mb-8"></div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">
                Kansas City tours done right since 2015.
              </h3>
              <p className="text-slate-600 leading-relaxed mb-8">
                Barley Bus started with a simple idea: Kansas City is full of incredible experiences, but getting to them shouldn't be a hassle. What began as a single brewery tour has grown into Kansas City's most trusted tour operator, serving thousands of guests every year with the same passion and dedication we started with.
              </p>
              <button className="border-2 border-slate-900 text-slate-900 px-8 py-3 font-bold hover:bg-slate-900 hover:text-white transition-colors">
                LEARN MORE
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-5xl md:text-6xl font-black text-slate-900 mb-6">
                SAFETY FIRST
              </h2>
              <div className="w-16 h-1 bg-orange-600 mb-8"></div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">
                Your safety is our top priority.
              </h3>
              <p className="text-slate-600 leading-relaxed mb-8">
                Every guest's safety is our top priority. Our drivers are professionally trained, our buses are meticulously maintained, and we carry comprehensive insurance. When you ride with Barley Bus, you're in good hands so you can focus on having fun.
              </p>
              <button className="border-2 border-slate-900 text-slate-900 px-8 py-3 font-bold hover:bg-slate-900 hover:text-white transition-colors">
                CONTACT US
              </button>
            </div>
            <div>
              <img
                src="https://images.pexels.com/photos/1010657/pexels-photo-1010657.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Safety"
                className="w-full h-auto rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
