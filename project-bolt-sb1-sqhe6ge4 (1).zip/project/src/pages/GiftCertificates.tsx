import { Gift, Check } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const giftOptions = [
  {
    amount: 100,
    description: 'Perfect for brewery or distillery tours',
    popular: false
  },
  {
    amount: 200,
    description: 'Great for full-day experiences',
    popular: true
  },
  {
    amount: 300,
    description: 'Ideal for multi-day wine country escapes',
    popular: false
  },
  {
    amount: 500,
    description: 'Ultimate gift for special occasions',
    popular: false
  }
];

export default function GiftCertificates() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="pt-24 sm:pt-28 md:pt-32 pb-10 sm:pb-12 md:pb-16 bg-gradient-to-b from-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Gift className="w-16 h-16 text-orange-600 mx-auto mb-4" />
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-slate-900 mb-4 tracking-tight">
              GIFT CERTIFICATES
            </h1>
            <p className="text-lg sm:text-xl text-slate-600 max-w-3xl mx-auto">
              Give the gift of unforgettable Kansas City experiences
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {giftOptions.map((option) => (
              <div
                key={option.amount}
                className={`bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 relative ${
                  option.popular ? 'ring-2 ring-orange-600' : ''
                }`}
              >
                {option.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-orange-600 text-white px-4 py-1 rounded-full text-sm font-bold">
                    Most Popular
                  </div>
                )}
                <div className="text-center">
                  <div className="text-4xl font-black text-slate-900 mb-2">
                    ${option.amount}
                  </div>
                  <p className="text-slate-600 mb-6 min-h-[48px]">
                    {option.description}
                  </p>
                  <button className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-lg transition-colors duration-300">
                    Buy Now
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="bg-slate-100 rounded-2xl p-8">
              <h2 className="text-2xl font-bold text-slate-900 mb-6">Why Give Barley Bus?</h2>
              <ul className="space-y-4">
                {[
                  'Valid for any Barley Bus tour or experience',
                  'No expiration date - use anytime',
                  'Perfect for birthdays, holidays, or special occasions',
                  'Delivered instantly via email',
                  'Can be combined with other offers',
                  'Fully transferable to friends and family'
                ].map((benefit) => (
                  <li key={benefit} className="flex items-start gap-3">
                    <Check className="w-6 h-6 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-700">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-slate-900 mb-6">Custom Amount</h2>
              <p className="text-slate-600 mb-6">
                Want to give a different amount? Enter a custom value below.
              </p>

              <form className="space-y-4">
                <div>
                  <label htmlFor="custom-amount" className="block text-sm font-semibold text-slate-900 mb-2">
                    Gift Amount
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 text-lg">
                      $
                    </span>
                    <input
                      type="number"
                      id="custom-amount"
                      min="25"
                      step="5"
                      className="w-full pl-8 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none text-lg"
                      placeholder="100"
                    />
                  </div>
                  <p className="text-sm text-slate-500 mt-2">Minimum $25</p>
                </div>

                <div>
                  <label htmlFor="recipient-email" className="block text-sm font-semibold text-slate-900 mb-2">
                    Recipient Email
                  </label>
                  <input
                    type="email"
                    id="recipient-email"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none"
                    placeholder="recipient@email.com"
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-slate-900 mb-2">
                    Personal Message (Optional)
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none resize-none"
                    placeholder="Add a personal message to your gift..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-4 rounded-lg transition-colors duration-300"
                >
                  Purchase Gift Certificate
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
