import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import UpcomingTrips from '../components/UpcomingTrips';
import TourGrid from '../components/TourGrid';
import HowItWorks from '../components/HowItWorks';
import SocialProof from '../components/SocialProof';
import FeaturedTour from '../components/FeaturedTour';
import VideoSection from '../components/VideoSection';
import WallOfLove from '../components/WallOfLove';
import PrivateEvents from '../components/PrivateEvents';
import FAQ from '../components/FAQ';
import Footer from '../components/Footer';
import StickyBookButton from '../components/StickyBookButton';
import { LocalBusinessSchema } from '../components/SchemaMarkup';

function Home() {
  return (
    <div className="min-h-screen bg-white">
      <LocalBusinessSchema reviewCount={450} averageRating={4.9} />
      <Navbar />
      <StickyBookButton />
      <Hero />
      <UpcomingTrips />
      <TourGrid />
      <HowItWorks />
      <SocialProof />
      <FeaturedTour />
      <VideoSection />
      <WallOfLove />
      <PrivateEvents />
      <FAQ />
      <Footer />
    </div>
  );
}

export default Home;
