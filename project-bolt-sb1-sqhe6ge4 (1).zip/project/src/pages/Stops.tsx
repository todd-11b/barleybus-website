import { MapPin, Beer, Wine, Martini, UtensilsCrossed } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const stopCategories = [
  {
    title: 'Breweries',
    icon: Beer,
    color: 'text-amber-600',
    locations: [
      'Boulevard Brewing Company',
      'KC Bier Co',
      'Martin City Brewing Company',
      'Crane Brewing Company',
      'Double Shift Brewing Company',
      'Big Rip Brewing Company'
    ]
  },
  {
    title: 'Distilleries',
    icon: Martini,
    color: 'text-slate-700',
    locations: [
      'J. Rieger & Co.',
      'Tom\'s Town Distilling Co.',
      'Union Horse Distilling Co.',
      'Restless Spirits Distilling',
      'Lifted Spirits Distillery'
    ]
  },
  {
    title: 'Wineries',
    icon: Wine,
    color: 'text-red-600',
    locations: [
      'Amigoni Urban Winery',
      'Stonehaus Farms Winery',
      'Aubrey Vineyards',
      'Van Till Family Farm Winery',
      'Belvoir Winery'
    ]
  },
  {
    title: 'BBQ & Food Spots',
    icon: UtensilsCrossed,
    color: 'text-orange-600',
    locations: [
      'Joe\'s Kansas City BBQ',
      'Q39',
      'Jack Stack Barbecue',
      'Arthur Bryant\'s',
      'LC\'s Bar-B-Q',
      'Gates Bar-B-Q'
    ]
  }
];

export default function Stops() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="pt-24 sm:pt-28 md:pt-32 pb-10 sm:pb-12 md:pb-16 bg-gradient-to-b from-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-slate-900 text-center mb-4 tracking-tight">
            OUR STOPS
          </h1>
          <p className="text-center text-slate-600 text-lg sm:text-xl max-w-3xl mx-auto mb-12">
            Explore Kansas City's finest breweries, distilleries, wineries, and food destinations
          </p>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {stopCategories.map((category) => {
              const Icon = category.icon;
              return (
                <div key={category.title} className="bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300">
                  <div className="flex items-center gap-3 mb-6">
                    <Icon className={`w-8 h-8 ${category.color}`} />
                    <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
                      {category.title}
                    </h2>
                  </div>
                  <ul className="space-y-3">
                    {category.locations.map((location) => (
                      <li key={location} className="flex items-start gap-2 text-slate-700">
                        <MapPin className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                        <span className="text-lg">{location}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>

          <div className="bg-slate-100 rounded-2xl p-8 text-center">
            <h3 className="text-2xl font-bold text-slate-900 mb-4">
              Stop Selection Varies by Tour
            </h3>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              The specific stops on your tour may vary based on availability, tour type, and group preferences.
              Our expert guides will ensure you visit the best locations for an unforgettable experience.
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
