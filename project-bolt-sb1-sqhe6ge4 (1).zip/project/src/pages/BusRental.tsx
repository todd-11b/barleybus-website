import { Bus, Clock, Users, MapPin, Check, Shield } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const rentalFeatures = [
  'Professional, licensed drivers',
  'Clean, well-maintained vehicles',
  'Flexible pickup and drop-off locations',
  'Customizable routes and schedules',
  'Sound system and climate control',
  'Fully insured and permitted'
];

const rentalOptions = [
  {
    name: 'Half Day Rental',
    duration: '4 hours',
    capacity: 'Up to 14 passengers',
    price: 'Starting at $400',
    ideal: 'Perfect for short trips, airport transfers, or quick tours'
  },
  {
    name: 'Full Day Rental',
    duration: '8 hours',
    capacity: 'Up to 14 passengers',
    price: 'Starting at $700',
    ideal: 'Great for full-day events, weddings, or extended tours',
    popular: true
  },
  {
    name: 'Multi-Day Rental',
    duration: 'Custom duration',
    capacity: 'Up to 14 passengers',
    price: 'Custom pricing',
    ideal: 'Ideal for conventions, conferences, or extended trips'
  }
];

export default function BusRental() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="relative h-64 sm:h-80 md:h-96 overflow-hidden">
        <img
          src="https://images.pexels.com/photos/1047442/pexels-photo-1047442.jpeg?auto=compress&cs=tinysrgb&w=1600"
          alt="Bus Rental"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 to-slate-900/50 flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-white mb-4">
              KC BUS RENTAL
            </h1>
            <p className="text-lg sm:text-xl text-white/90 max-w-2xl">
              Professional transportation services for any occasion in Kansas City
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 md:py-20">
        <div className="mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
            Your Private Transportation Solution
          </h2>
          <p className="text-lg text-slate-600 leading-relaxed">
            Need reliable, professional transportation in Kansas City? Barley Bus offers flexible charter services
            for any occasion. Whether you're planning a corporate event, wedding transportation, airport transfers,
            or a custom tour, our modern fleet and experienced drivers ensure a comfortable, safe journey.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {rentalOptions.map((option) => (
            <div
              key={option.name}
              className={`bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 relative ${
                option.popular ? 'ring-2 ring-orange-600' : ''
              }`}
            >
              {option.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-orange-600 text-white px-4 py-1 rounded-full text-sm font-bold">
                  Most Popular
                </div>
              )}
              <Bus className="w-12 h-12 text-orange-600 mb-4" />
              <h3 className="text-2xl font-bold text-slate-900 mb-3">{option.name}</h3>

              <div className="space-y-2 mb-6">
                <div className="flex items-center gap-2 text-slate-600">
                  <Clock className="w-5 h-5 text-orange-600" />
                  <span>{option.duration}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-600">
                  <Users className="w-5 h-5 text-orange-600" />
                  <span>{option.capacity}</span>
                </div>
              </div>

              <div className="text-2xl font-black text-slate-900 mb-3">
                {option.price}
              </div>

              <p className="text-slate-600 mb-6 min-h-[48px]">
                {option.ideal}
              </p>

              <button className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-lg transition-colors duration-300">
                Get Quote
              </button>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-slate-100 rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">What's Included</h2>
            <div className="space-y-4">
              {rentalFeatures.map((feature) => (
                <div key={feature} className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-orange-600 flex-shrink-0 mt-0.5" />
                  <span className="text-slate-700 text-lg">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8">
            <Shield className="w-12 h-12 text-orange-600 mb-4" />
            <h2 className="text-2xl font-bold text-slate-900 mb-4">
              Safe & Reliable
            </h2>
            <p className="text-slate-600 mb-6 leading-relaxed">
              Your safety is our top priority. All our drivers undergo rigorous background checks and maintain
              commercial licenses. Our vehicles are regularly inspected and maintained to the highest standards.
              We're fully insured and permitted to operate throughout the Kansas City metro area.
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-orange-600" />
                <span className="text-slate-700">DOT Certified Vehicles</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-orange-600" />
                <span className="text-slate-700">Licensed & Insured Drivers</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-orange-600" />
                <span className="text-slate-700">24/7 Customer Support</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-6 text-center">
            Request a Rental Quote
          </h2>

          <form className="max-w-3xl mx-auto space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none"
                  placeholder="John Smith"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none"
                  placeholder="john@email.com"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Phone
                </label>
                <input
                  type="tel"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none"
                  placeholder="(816) 555-1234"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Number of Passengers
                </label>
                <input
                  type="number"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none"
                  placeholder="10"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Rental Date
                </label>
                <input
                  type="date"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Duration
                </label>
                <select className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none">
                  <option>4 hours</option>
                  <option>8 hours</option>
                  <option>Multi-day</option>
                  <option>Custom</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">
                Pickup Location
              </label>
              <input
                type="text"
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none"
                placeholder="Address or landmark"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">
                Event Details & Special Requests
              </label>
              <textarea
                rows={4}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none resize-none"
                placeholder="Tell us about your event and any special requirements..."
              />
            </div>

            <button
              type="submit"
              className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-4 rounded-lg transition-colors duration-300"
            >
              Request Quote
            </button>
          </form>
        </div>
      </div>

      <Footer />
    </div>
  );
}
