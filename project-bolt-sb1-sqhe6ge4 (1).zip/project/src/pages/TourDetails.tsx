import { useParams } from 'react-router-dom';
import { useState } from 'react';
import { MapPin, Clock, Users, Star, Share2, Check, ChevronLeft, ChevronRight } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const TourDetails = () => {
  const { slug, id } = useParams();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [selectedDate, setSelectedDate] = useState('');
  const [guestCount, setGuestCount] = useState(1);

  const tourSlug = slug || id || 'kc-brewery-tour';

  const tourData: Record<string, any> = {
    'kc-brewery-tour': {
      title: 'Kansas City Brewery Tour',
      location: 'Kansas City, MO',
      rating: 5.0,
      reviewCount: 24,
      images: [
        '/Barley-Bus-home-banner.jpg',
        '/sightseeing.webp',
        '/Barley-Bus-home-banner.jpg'
      ],
      price: 60,
      duration: '4-5 hours',
      maxCapacity: 14,
      overview: 'Experience the best of Kansas City\'s craft beer scene on this exciting brewery tour. Visit 3-4 award-winning breweries and sample a variety of unique craft beers while learning about the brewing process from expert guides.',
      highlights: [
        'Visit 3-4 award-winning breweries',
        'Sample 12+ unique craft beers',
        'Behind-the-scenes brewery tours',
        'Expert beer guide',
        'All transportation included',
        'Souvenir tasting glass'
      ],
      itinerary: [
        {
          time: '1:00 PM',
          title: 'Departure - Kansas City Crossroads',
          description: 'Meet at our departure point in the historic Crossroads Arts District. Board our comfortable tour bus and begin your brewery adventure.'
        },
        {
          time: '1:30 PM',
          title: 'First Brewery Stop',
          description: 'Visit our first brewery for a guided tour and tasting session. Learn about the brewing process and sample 3-4 craft beers.'
        },
        {
          time: '2:45 PM',
          title: 'Second Brewery Stop',
          description: 'Continue to Boulevard Brewing Company for an exclusive behind-the-scenes tour and tasting of their seasonal offerings.'
        },
        {
          time: '4:00 PM',
          title: 'Third Brewery Stop',
          description: 'Visit a local favorite brewery in the River Market area. Sample unique craft offerings and enjoy light snacks.'
        },
        {
          time: '5:30 PM',
          title: 'Return',
          description: 'Return to the original departure point with unforgettable memories and your souvenir tasting glass.'
        }
      ],
      included: [
        'Professional tour guide',
        'Transportation on comfortable tour bus',
        'Brewery tours and tastings',
        'Souvenir tasting glass',
        'Light snacks',
        'Bottled water'
      ],
      notIncluded: [
        'Gratuities',
        'Additional food or drinks',
        'Hotel pickup/drop-off'
      ],
      cancellationPolicy: 'Free cancellation up to 24 hours before the tour starts. Cancellations within 24 hours are non-refundable.',
      faqs: [
        {
          question: 'What should I bring?',
          answer: 'Please bring a valid ID (21+ required), comfortable walking shoes, and a camera to capture memories!'
        },
        {
          question: 'Is food included?',
          answer: 'Light snacks are provided, but we recommend eating before the tour. You\'ll also have opportunities to purchase food at some brewery stops.'
        },
        {
          question: 'What happens if it rains?',
          answer: 'Tours run rain or shine! Our bus provides comfortable covered transportation between breweries.'
        }
      ],
      reviews: [
        {
          name: 'Sarah M.',
          rating: 5,
          date: '2 weeks ago',
          text: 'Absolutely amazing experience! Our guide was knowledgeable and the breweries were fantastic. Perfect way to explore KC\'s beer scene!'
        },
        {
          name: 'Mike R.',
          rating: 5,
          date: '1 month ago',
          text: 'Best brewery tour I\'ve been on. Great selection of breweries and the guide made it so fun. Highly recommend!'
        }
      ]
    }
  };

  const tour = tourData[tourSlug] || tourData['kc-brewery-tour'];

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % tour.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + tour.images.length) % tour.images.length);
  };

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'highlights', label: 'Highlights' },
    { id: 'itinerary', label: 'Itinerary' },
    { id: 'included', label: "What's Included" },
    { id: 'cancellation', label: 'Cancellation' },
    { id: 'faqs', label: 'FAQs' },
    { id: 'reviews', label: 'Reviews' }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="container mx-auto px-4 py-8 pt-24">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-2/3">
            <div className="relative mb-6 rounded-xl overflow-hidden">
              <img
                src={tour.images[currentImageIndex]}
                alt={tour.title}
                className="w-full h-[400px] object-cover"
              />
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg transition-all"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg transition-all"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>

            <div className="mb-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-4xl font-bold mb-3">{tour.title}</h1>
                  <div className="flex items-center gap-4 text-gray-600 mb-2">
                    <div className="flex items-center gap-1">
                      <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
                      <span className="font-semibold">{tour.rating}</span>
                      <span>({tour.reviewCount} reviews)</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-5 h-5" />
                      <span>{tour.location}</span>
                    </div>
                  </div>
                </div>
                <button className="p-2 hover:bg-gray-100 rounded-full transition-all">
                  <Share2 className="w-5 h-5" />
                </button>
              </div>

              <div className="flex items-center gap-6 py-4 border-t border-b border-gray-200">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-gray-600" />
                  <div>
                    <div className="text-sm text-gray-600">Duration</div>
                    <div className="font-semibold">{tour.duration}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-gray-600" />
                  <div>
                    <div className="text-sm text-gray-600">Group Size</div>
                    <div className="font-semibold">Up to {tour.maxCapacity}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-gray-600" />
                  <div>
                    <div className="text-sm text-gray-600">Location</div>
                    <div className="font-semibold">Kansas City</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="border-b border-gray-200 mb-6 sticky top-16 md:top-20 bg-white z-10 -mx-4 px-4">
              <div className="flex gap-1 overflow-x-auto scrollbar-hide">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      const element = document.getElementById(tab.id);
                      element?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }}
                    className="px-3 md:px-4 py-3 font-medium whitespace-nowrap text-gray-700 hover:text-gray-900 transition-all text-sm md:text-base"
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-12">
              <div id="overview">
                <h2 className="text-2xl font-bold mb-4">Overview</h2>
                <p className="text-gray-700 leading-relaxed">{tour.overview}</p>
              </div>

              <div id="highlights">
                <h2 className="text-2xl font-bold mb-4">Highlights</h2>
                <ul className="space-y-3">
                  {tour.highlights.map((highlight: string, idx: number) => (
                    <li key={idx} className="flex items-start gap-3">
                      <Check className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{highlight}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div id="itinerary">
                <h2 className="text-2xl font-bold mb-4">Itinerary</h2>
                <div className="space-y-6">
                  {tour.itinerary.map((stop: any, idx: number) => (
                    <div key={idx} className="flex gap-4">
                      <div className="flex-shrink-0">
                        <div className="bg-orange-500 text-white font-semibold px-3 py-1 rounded">
                          {stop.time}
                        </div>
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg mb-1">{stop.title}</h3>
                        <p className="text-gray-700">{stop.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div id="included">
                <h2 className="text-2xl font-bold mb-6">What's Included</h2>
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold mb-3 text-green-700">Included</h3>
                    <ul className="space-y-2">
                      {tour.included.map((item: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-2">
                          <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700 text-sm sm:text-base">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-3 text-red-700">Not Included</h3>
                    <ul className="space-y-2">
                      {tour.notIncluded.map((item: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-2 text-gray-700">
                          <span className="text-sm sm:text-base">•</span>
                          <span className="text-sm sm:text-base">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              <div id="cancellation">
                <h2 className="text-2xl font-bold mb-4">Cancellation Policy</h2>
                <p className="text-gray-700">{tour.cancellationPolicy}</p>
              </div>

              <div id="faqs">
                <h2 className="text-2xl font-bold mb-4">FAQs</h2>
                <div className="space-y-4">
                  {tour.faqs.map((faq: any, idx: number) => (
                    <div key={idx} className="border-b border-gray-200 pb-4">
                      <h3 className="font-semibold mb-2">{faq.question}</h3>
                      <p className="text-gray-700">{faq.answer}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div id="reviews">
                <h2 className="text-2xl font-bold mb-4">Reviews</h2>
                <div className="space-y-6">
                  {tour.reviews.map((review: any, idx: number) => (
                    <div key={idx} className="border-b border-gray-200 pb-6">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < review.rating
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="font-semibold">{review.name}</span>
                        <span className="text-gray-500 text-sm">{review.date}</span>
                      </div>
                      <p className="text-gray-700">{review.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="lg:w-1/3">
            <div className="sticky top-4 bg-white border border-gray-200 rounded-xl p-6 shadow-lg">
              <div className="mb-6">
                <div className="text-sm text-gray-600 mb-1">from</div>
                <div className="text-4xl font-bold">${tour.price} <span className="text-lg text-gray-600 font-normal">/person</span></div>
              </div>

              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Select Date
                  </label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Guests
                  </label>
                  <select
                    value={guestCount}
                    onChange={(e) => setGuestCount(Number(e.target.value))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    {[...Array(tour.maxCapacity)].map((_, i) => (
                      <option key={i} value={i + 1}>
                        {i + 1} Guest{i > 0 ? 's' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <button className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 rounded-lg mb-4 transition-all">
                Check availability
              </button>

              <div className="border-t border-gray-200 pt-4">
                <h3 className="font-semibold mb-3">Why booking with Togo?</h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span>Free cancellation up to 24 hours</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <span>Trusted by 100K+ travelers</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default TourDetails;
