import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import WallOfLove from '../components/WallOfLove';
import ReviewStars from '../components/ReviewStars';

export default function Reviews() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="pt-24 sm:pt-28 md:pt-32 pb-10 sm:pb-12 md:pb-16 bg-gradient-to-b from-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-slate-900 mb-4 tracking-tight">
              CUSTOMER REVIEWS
            </h1>
            <p className="text-lg sm:text-xl text-slate-600 max-w-3xl mx-auto mb-6">
              See what our guests are saying about their Barley Bus experiences
            </p>
            <div className="flex items-center justify-center gap-3">
              <ReviewStars rating={4.9} size="large" />
              <span className="text-2xl font-bold text-slate-900">4.9/5</span>
              <span className="text-slate-600">from 500+ reviews</span>
            </div>
          </div>
        </div>
      </div>

      <WallOfLove />

      <div className="bg-slate-50 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-6">
            Join Thousands of Happy Guests
          </h2>
          <p className="text-lg text-slate-600 mb-8">
            Ready to create your own unforgettable experience? Book your tour today and see why Barley Bus
            is Kansas City's favorite way to explore.
          </p>
          <a
            href="/#tours"
            className="inline-block bg-orange-600 hover:bg-orange-700 text-white font-bold px-8 py-4 rounded-lg transition-colors duration-300"
          >
            Browse Our Tours
          </a>
        </div>
      </div>

      <Footer />
    </div>
  );
}
