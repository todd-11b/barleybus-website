import { Download as DownloadIcon } from 'lucide-react';
import { useState } from 'react';

export default function Download() {
  const downloadUrl = 'https://jrqdzamskmohqihibjuq.supabase.co/storage/v1/object/public/website-downloads/barleybus-website.zip';
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const response = await fetch(downloadUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'barleybus-website.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed:', error);
      alert('Download failed. Please try the direct link below.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
        <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <DownloadIcon className="w-10 h-10 text-amber-600" />
        </div>

        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          Barley Bus Website
        </h1>

        <p className="text-gray-600 mb-8">
          Click the button below to download the website files (1.9 MB).
        </p>

        <button
          onClick={handleDownload}
          disabled={downloading}
          className="inline-flex items-center gap-2 bg-amber-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-amber-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <DownloadIcon className="w-5 h-5" />
          {downloading ? 'Downloading...' : 'Download Website'}
        </button>

        <div className="mt-8 pt-8 border-t border-gray-200">
          <p className="text-sm text-gray-500 mb-2">
            File: barleybus-website.zip
          </p>
          <a
            href={downloadUrl}
            download="barleybus-website.zip"
            className="text-sm text-amber-600 hover:text-amber-700 inline-block"
          >
            Direct download link
          </a>
        </div>
      </div>
    </div>
  );
}
