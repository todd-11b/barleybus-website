import { Users, Calendar, MapPin, Clock, Check } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import PrivateTourCalculator from '../components/PrivateTourCalculator';

const groupBenefits = [
  'Customizable itinerary to match your group\'s interests',
  'Private transportation for your entire party',
  'Flexible scheduling - choose your date and time',
  'Expert local guide dedicated to your group',
  'Special group rates and discounts',
  'Perfect for corporate events, reunions, celebrations'
];

const groupSizes = [
  { size: '8-14 guests', vehicle: 'Standard Bus', ideal: 'Small groups, intimate tours' },
  { size: '15-24 guests', vehicle: 'Large Bus', ideal: 'Medium groups, corporate outings' },
  { size: '25+ guests', vehicle: 'Multiple Vehicles', ideal: 'Large events, conferences' }
];

export default function GroupTours() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="relative h-64 sm:h-80 md:h-96 overflow-hidden">
        <img
          src="https://images.pexels.com/photos/3171815/pexels-photo-3171815.jpeg?auto=compress&cs=tinysrgb&w=1600"
          alt="Group Tours"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 to-slate-900/50 flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-white mb-4">
              GROUP TOURS
            </h1>
            <p className="text-lg sm:text-xl text-white/90 max-w-2xl">
              Unforgettable experiences for corporate events, celebrations, and large parties
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 md:py-20">
        <div className="mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
            Perfect for Any Group Size
          </h2>
          <p className="text-lg text-slate-600 leading-relaxed">
            Whether you're planning a corporate team-building event, family reunion, bachelor/bachelorette party,
            or any special celebration, Barley Bus provides customized group tours that create lasting memories.
            Our experienced team will work with you to create the perfect itinerary for your group.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {groupSizes.map((group) => (
            <div key={group.size} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
              <Users className="w-12 h-12 text-orange-600 mb-4" />
              <h3 className="text-2xl font-bold text-slate-900 mb-2">{group.size}</h3>
              <p className="text-slate-600 font-semibold mb-2">{group.vehicle}</p>
              <p className="text-slate-600">{group.ideal}</p>
            </div>
          ))}
        </div>

        <div className="bg-slate-100 rounded-2xl p-8 mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-6 text-center">
            Why Choose Group Tours?
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {groupBenefits.map((benefit) => (
              <div key={benefit} className="flex items-start gap-3">
                <Check className="w-6 h-6 text-orange-600 flex-shrink-0 mt-0.5" />
                <span className="text-slate-700 text-lg">{benefit}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Popular Group Tours</h2>
            <div className="space-y-6">
              {[
                { name: 'Corporate Team Building', icon: Users, desc: 'Strengthen team bonds with brewery tours and team activities' },
                { name: 'Bachelor/Bachelorette Parties', icon: Calendar, desc: 'Celebrate in style with customized party bus experiences' },
                { name: 'Birthday Celebrations', icon: Calendar, desc: 'Make birthdays unforgettable with private tours' },
                { name: 'Family Reunions', icon: Users, desc: 'Bring the family together for KC sightseeing and food tours' }
              ].map((tour) => {
                const Icon = tour.icon;
                return (
                  <div key={tour.name} className="flex gap-4">
                    <Icon className="w-8 h-8 text-orange-600 flex-shrink-0" />
                    <div>
                      <h3 className="font-bold text-slate-900 mb-1">{tour.name}</h3>
                      <p className="text-slate-600">{tour.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Request a Quote</h2>
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Company/Group Name
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none"
                  placeholder="Your organization"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Group Size
                </label>
                <input
                  type="number"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none"
                  placeholder="Number of guests"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Preferred Date
                </label>
                <input
                  type="date"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Contact Email
                </label>
                <input
                  type="email"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none"
                  placeholder="your@email.com"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Additional Details
                </label>
                <textarea
                  rows={4}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-600 focus:border-transparent outline-none resize-none"
                  placeholder="Tell us about your event..."
                />
              </div>
              <button
                type="submit"
                className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-4 rounded-lg transition-colors duration-300"
              >
                Request Quote
              </button>
            </form>
          </div>
        </div>

        <PrivateTourCalculator />
      </div>

      <Footer />
    </div>
  );
}
