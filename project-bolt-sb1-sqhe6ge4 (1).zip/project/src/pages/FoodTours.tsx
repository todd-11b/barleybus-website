import { Star, Clock, Users, MapPin, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Button from '../components/Button';

const foodTours = [
  {
    title: 'Barbecue & Beer Tour',
    slug: 'barbecue-beer-tour',
    duration: '4 hours',
    groupSize: 'Up to 14 people',
    stops: '4-5 locations',
    price: 99,
    rating: 5,
    reviews: 56,
    image: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg?auto=compress&cs=tinysrgb&w=1200',
    description: 'Combine KC\'s legendary barbecue with craft beer at the city\'s most iconic spots for the ultimate taste experience.',
    highlights: [
      'Sample Kansas City\'s best BBQ',
      'Visit 2-3 BBQ institutions',
      'Pair with local craft beers',
      'Learn KC BBQ history',
      'Transportation and guide included'
    ]
  }
];

export default function FoodTours() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="relative h-64 sm:h-80 md:h-96 overflow-hidden">
        <img
          src="https://images.pexels.com/photos/5591663/pexels-photo-5591663.jpeg?auto=compress&cs=tinysrgb&w=1600"
          alt="Food Tours"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 to-slate-900/50 flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-white mb-4">
              FOOD TOURS
            </h1>
            <p className="text-lg sm:text-xl text-white/90 max-w-2xl">
              Taste the legendary flavors that make Kansas City a culinary destination
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 md:py-20">
        <div className="mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
            Why Choose Our Food Tours?
          </h2>
          <p className="text-lg text-slate-600 leading-relaxed">
            Kansas City is world-renowned for its barbecue, and our food tours showcase why. We'll take you to the
            legendary pitmasters and hidden gems that define Kansas City's culinary scene. From slow-smoked brisket
            to burnt ends, ribs to pulled pork, you'll taste it all while learning the rich history and traditions
            that make KC BBQ truly special. Come hungry!
          </p>
        </div>

        <div className="grid gap-8">
          {foodTours.map((tour) => (
            <div key={tour.slug} className="bg-white rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300">
              <div className="grid md:grid-cols-5 gap-0">
                <div className="md:col-span-2 relative h-64 md:h-auto overflow-hidden">
                  <img
                    src={tour.image}
                    alt={tour.title}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                  />
                </div>

                <div className="md:col-span-3 p-6 sm:p-8 bg-slate-50">
                  <h3 className="text-2xl sm:text-3xl font-black text-slate-900 mb-4">
                    {tour.title}
                  </h3>

                  <div className="flex items-center gap-2 mb-4">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(tour.rating)
                              ? 'fill-orange-500 text-orange-500'
                              : 'fill-slate-300 text-slate-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-slate-600 text-sm">{tour.reviews} Reviews</span>
                  </div>

                  <p className="text-slate-600 mb-6 leading-relaxed">
                    {tour.description}
                  </p>

                  <div className="grid grid-cols-3 gap-4 mb-6">
                    <div className="flex items-center gap-2 text-slate-700">
                      <Clock className="w-5 h-5 text-orange-600" />
                      <span className="text-sm">{tour.duration}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-700">
                      <Users className="w-5 h-5 text-orange-600" />
                      <span className="text-sm">{tour.groupSize}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-700">
                      <MapPin className="w-5 h-5 text-orange-600" />
                      <span className="text-sm">{tour.stops}</span>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg p-4 mb-6">
                    <h4 className="font-bold text-slate-900 mb-3">Tour Highlights:</h4>
                    <ul className="space-y-2">
                      {tour.highlights.map((highlight, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-slate-600">
                          <ChevronRight className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                          <span>{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <span className="text-4xl font-black text-slate-900">
                        ${tour.price}
                      </span>
                      <span className="text-slate-500 ml-2">per person</span>
                    </div>
                    <Button onClick={() => navigate(`/tours/${tour.slug}`)}>
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
}
