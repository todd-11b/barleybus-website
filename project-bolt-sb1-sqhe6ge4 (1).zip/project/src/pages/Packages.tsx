import { Star, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

interface PackageCardProps {
  location: string;
  title: string;
  days: number;
  nights: number;
  reviews: number;
  rating: number;
  description: string;
  price: number;
  originalPrice: number;
  image: string;
  slug: string;
}

const PackageCard = ({
  location,
  title,
  days,
  nights,
  reviews,
  rating,
  description,
  price,
  originalPrice,
  image,
  slug,
}: PackageCardProps) => {
  const navigate = useNavigate();
  return (
    <div className="bg-white rounded-xl sm:rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group">
      <div className="grid md:grid-cols-2 gap-0">
        <div className="relative h-48 sm:h-64 md:h-full overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          />
          <div className="absolute top-3 left-3 sm:top-4 sm:left-4">
            <span className="bg-orange-600 text-white px-3 py-1 sm:px-4 sm:py-1.5 rounded-full font-bold text-xs sm:text-sm">
              {location}
            </span>
          </div>
        </div>

        <div className="p-4 sm:p-6 md:p-8 bg-gray-100 flex flex-col justify-between">
          <div>
            <div className="text-slate-600 text-xs sm:text-sm font-semibold mb-2 tracking-wide uppercase">
              {days} Days / {nights} Nights
            </div>
            <h3 className="text-xl sm:text-2xl md:text-3xl font-black text-slate-900 mb-3 sm:mb-4 leading-tight">
              {title}
            </h3>

            <div className="flex items-center gap-2 mb-3 sm:mb-4">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${
                      i < Math.floor(rating)
                        ? 'fill-orange-500 text-orange-500'
                        : 'fill-slate-300 text-slate-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-slate-600 text-xs sm:text-sm">{reviews} Reviews</span>
            </div>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed mb-4 sm:mb-6">{description}</p>
          </div>

          <div className="flex items-end justify-between gap-3">
            <div>
              <div className="flex items-baseline gap-2 mb-1">
                <span className="text-2xl sm:text-3xl md:text-4xl font-black text-slate-900">
                  ${price}
                </span>
                <span className="text-base sm:text-lg text-slate-400 line-through">
                  ${originalPrice}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500">per person</p>
            </div>

            <button
              onClick={() => navigate(`/tours/${slug}`)}
              className="bg-orange-600 hover:bg-orange-700 text-white w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110 group-hover:shadow-xl flex-shrink-0"
            >
              <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function Packages() {
  const packages: PackageCardProps[] = [
    {
      location: 'Kansas City',
      title: 'BREWERY TOUR.',
      days: 1,
      nights: 0,
      reviews: 48,
      rating: 5,
      description:
        'Experience Kansas City\'s thriving craft beer scene with visits to award-winning breweries and behind-the-scenes tours.',
      price: 89,
      originalPrice: 120,
      image: 'https://images.pexels.com/photos/1267696/pexels-photo-1267696.jpeg?auto=compress&cs=tinysrgb&w=1200',
      slug: 'kc-brewery-tour',
    },
    {
      location: 'Kansas City',
      title: 'WINE COUNTRY ESCAPE.',
      days: 2,
      nights: 1,
      reviews: 32,
      rating: 5,
      description:
        'Discover Missouri wine country with tastings at premier wineries, vineyard tours, and scenic countryside views.',
      price: 299,
      originalPrice: 399,
      image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg?auto=compress&cs=tinysrgb&w=1200',
      slug: 'wine-country-escape',
    },
    {
      location: 'Kansas City',
      title: 'DISTILLERY ADVENTURE.',
      days: 1,
      nights: 0,
      reviews: 27,
      rating: 5,
      description:
        'Tour Kansas City\'s finest distilleries, learn the art of craft spirits, and taste premium whiskeys and bourbons.',
      price: 95,
      originalPrice: 130,
      image: 'https://images.pexels.com/photos/1267358/pexels-photo-1267358.jpeg?auto=compress&cs=tinysrgb&w=1200',
      slug: 'distillery-adventure',
    },
    {
      location: 'Kansas City',
      title: 'BARBECUE & BEER TOUR.',
      days: 1,
      nights: 0,
      reviews: 56,
      rating: 5,
      description:
        'Combine KC\'s legendary barbecue with craft beer at the city\'s most iconic spots for the ultimate taste experience.',
      price: 99,
      originalPrice: 135,
      image: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg?auto=compress&cs=tinysrgb&w=1200',
      slug: 'barbecue-beer-tour',
    },
    {
      location: 'Kansas City',
      title: 'HOLIDAY LIGHTS TOUR.',
      days: 1,
      nights: 0,
      reviews: 41,
      rating: 5,
      description:
        'Celebrate the season with a magical tour of Kansas City\'s most spectacular holiday light displays and decorations.',
      price: 79,
      originalPrice: 100,
      image: 'https://images.pexels.com/photos/3304703/pexels-photo-3304703.jpeg?auto=compress&cs=tinysrgb&w=1200',
      slug: 'holiday-lights-tour',
    },
    {
      location: 'Kansas City',
      title: 'SIGHTSEEING EXCURSION.',
      days: 1,
      nights: 0,
      reviews: 38,
      rating: 5,
      description:
        'Explore Kansas City\'s landmarks, cultural attractions, and hidden gems on this comprehensive city tour.',
      price: 69,
      originalPrice: 90,
      image: '/sightseeing.webp',
      slug: 'sightseeing-excursion',
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="pt-24 sm:pt-28 md:pt-32 pb-10 sm:pb-12 md:pb-16 bg-gradient-to-b from-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-slate-900 text-center mb-3 sm:mb-4 tracking-tight">
            POPULAR PACKAGES
          </h1>
          <p className="text-center text-slate-600 text-sm sm:text-base md:text-lg max-w-2xl mx-auto mb-8 sm:mb-12 md:mb-16 px-4">
            Discover our curated tour experiences designed for unforgettable adventures
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 md:gap-8">
            {packages.map((pkg, index) => (
              <PackageCard key={index} {...pkg} />
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
