import { Star, Clock, Users, MapPin, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Button from '../components/Button';

const wineryTours = [
  {
    title: 'Wine Country Escape',
    slug: 'wine-country-escape',
    duration: '2 days',
    groupSize: 'Up to 12 people',
    stops: '4-5 wineries',
    price: 299,
    rating: 5,
    reviews: 32,
    image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg?auto=compress&cs=tinysrgb&w=1200',
    description: 'Discover Missouri wine country with tastings at premier wineries, vineyard tours, and scenic countryside views.',
    highlights: [
      'Visit 4-5 boutique wineries',
      'Vineyard tours and wine education',
      'Premium wine tastings',
      'Scenic countryside drive',
      'Overnight accommodation included'
    ]
  }
];

export default function WineryTours() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="relative h-64 sm:h-80 md:h-96 overflow-hidden">
        <img
          src="https://images.pexels.com/photos/1024960/pexels-photo-1024960.jpeg?auto=compress&cs=tinysrgb&w=1600"
          alt="Winery Tours"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 to-slate-900/50 flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-white mb-4">
              WINERY TOURS
            </h1>
            <p className="text-lg sm:text-xl text-white/90 max-w-2xl">
              Escape to Missouri wine country for an unforgettable tasting experience
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 md:py-20">
        <div className="mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
            Why Choose Our Winery Tours?
          </h2>
          <p className="text-lg text-slate-600 leading-relaxed">
            Missouri's wine country offers rolling hills, picturesque vineyards, and award-winning wines that rival
            those from more famous regions. Our winery tours take you beyond Kansas City to explore family-owned
            wineries where passion and tradition create exceptional wines. Enjoy guided tastings, meet the winemakers,
            and soak in the beauty of the countryside on this relaxing getaway.
          </p>
        </div>

        <div className="grid gap-8">
          {wineryTours.map((tour) => (
            <div key={tour.slug} className="bg-white rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300">
              <div className="grid md:grid-cols-5 gap-0">
                <div className="md:col-span-2 relative h-64 md:h-auto overflow-hidden">
                  <img
                    src={tour.image}
                    alt={tour.title}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                  />
                </div>

                <div className="md:col-span-3 p-6 sm:p-8 bg-slate-50">
                  <h3 className="text-2xl sm:text-3xl font-black text-slate-900 mb-4">
                    {tour.title}
                  </h3>

                  <div className="flex items-center gap-2 mb-4">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(tour.rating)
                              ? 'fill-orange-500 text-orange-500'
                              : 'fill-slate-300 text-slate-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-slate-600 text-sm">{tour.reviews} Reviews</span>
                  </div>

                  <p className="text-slate-600 mb-6 leading-relaxed">
                    {tour.description}
                  </p>

                  <div className="grid grid-cols-3 gap-4 mb-6">
                    <div className="flex items-center gap-2 text-slate-700">
                      <Clock className="w-5 h-5 text-orange-600" />
                      <span className="text-sm">{tour.duration}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-700">
                      <Users className="w-5 h-5 text-orange-600" />
                      <span className="text-sm">{tour.groupSize}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-700">
                      <MapPin className="w-5 h-5 text-orange-600" />
                      <span className="text-sm">{tour.stops}</span>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg p-4 mb-6">
                    <h4 className="font-bold text-slate-900 mb-3">Tour Highlights:</h4>
                    <ul className="space-y-2">
                      {tour.highlights.map((highlight, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-slate-600">
                          <ChevronRight className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                          <span>{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <span className="text-4xl font-black text-slate-900">
                        ${tour.price}
                      </span>
                      <span className="text-slate-500 ml-2">per person</span>
                    </div>
                    <Button onClick={() => navigate(`/tours/${tour.slug}`)}>
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
}
