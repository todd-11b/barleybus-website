import { useState, useEffect } from 'react';
import { Instagram } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import StickyBookButton from '../components/StickyBookButton';
import { supabase, UGCPhoto } from '../lib/supabase';

export default function Gallery() {
  const [photos, setPhotos] = useState<UGCPhoto[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPhotos();
  }, []);

  const loadPhotos = async () => {
    try {
      const { data, error } = await supabase
        .from('ugc_photos')
        .select('*')
        .eq('featured', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPhotos(data || []);
    } catch (error) {
      console.error('Error loading photos:', error);
    } finally {
      setLoading(false);
    }
  };

  const placeholderPhotos = [
    '/Barley-Bus-home-banner.jpg',
    '/sightseeing.webp',
    '/Barley-Bus-home-banner.jpg',
    '/sightseeing.webp',
    '/Barley-Bus-home-banner.jpg',
    '/sightseeing.webp',
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <StickyBookButton />

      <div className="relative h-[40vh] min-h-[300px] sm:min-h-[350px] md:min-h-[400px] bg-gradient-to-r from-amber-600 to-orange-600">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative container mx-auto px-3 sm:px-4 h-full flex items-center">
          <div className="max-w-3xl text-white">
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 sm:mb-6">Wall of Love</h1>
            <p className="text-base sm:text-lg md:text-xl lg:text-2xl opacity-90">
              Real guests. Real moments. Real fun.
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-3 sm:px-4 py-10 sm:py-12 md:py-16">
        <div className="max-w-6xl mx-auto mb-8 sm:mb-10 md:mb-12 text-center">
          <p className="text-sm sm:text-base md:text-lg text-gray-600 max-w-3xl mx-auto mb-6 sm:mb-8 px-4">
            These aren't stock photos. These are real people having the time of their lives on our
            tours. Your next unforgettable memory is one booking away.
          </p>
          <div className="flex items-center justify-center gap-2 sm:gap-3 text-gray-700 text-sm sm:text-base">
            <Instagram className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600" />
            <span>Tag us @barleybus to be featured</span>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 md:gap-6 max-w-7xl mx-auto">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="aspect-square bg-gray-200 rounded-lg sm:rounded-xl animate-pulse"></div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 md:gap-6 max-w-7xl mx-auto">
            {(photos.length > 0 ? photos : placeholderPhotos).map((photo, index) => {
              const photoUrl = typeof photo === 'string' ? photo : photo.photo_url;
              const caption = typeof photo === 'object' ? photo.caption : null;
              const guestName = typeof photo === 'object' ? photo.guest_name : null;
              const instagramUrl = typeof photo === 'object' ? photo.instagram_url : null;

              return (
                <div
                  key={typeof photo === 'string' ? index : photo.id}
                  className="group relative aspect-square rounded-lg sm:rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300"
                >
                  <img
                    src={photoUrl}
                    alt={caption || 'Guest photo'}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/0 to-black/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute bottom-0 left-0 right-0 p-3 sm:p-4 md:p-6 text-white">
                      {caption && <p className="text-xs sm:text-sm mb-1 sm:mb-2">{caption}</p>}
                      {guestName && (
                        <p className="text-xs text-gray-300">- {guestName}</p>
                      )}
                      {instagramUrl && (
                        <a
                          href={instagramUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 sm:gap-2 mt-2 sm:mt-3 text-xs text-amber-400 hover:text-amber-300"
                        >
                          <Instagram className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                          View on Instagram
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="max-w-4xl mx-auto mt-10 sm:mt-12 md:mt-16 bg-amber-50 rounded-xl sm:rounded-2xl p-6 sm:p-8 md:p-12 text-center">
          <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900 mb-3 sm:mb-4">Ready to Create Your Own Memories?</h2>
          <p className="text-sm sm:text-base md:text-lg text-gray-700 mb-6 sm:mb-8 max-w-2xl mx-auto px-4">
            Join thousands of guests who've experienced Kansas City the Barley Bus way. Your story
            starts with one click.
          </p>
          <button
            onClick={() => (window.location.href = '/packages')}
            className="bg-amber-500 hover:bg-amber-600 text-white font-bold py-3 px-6 sm:py-4 sm:px-10 text-sm sm:text-base rounded-lg transition-colors duration-200 shadow-lg hover:shadow-xl min-h-[48px]"
          >
            Book Your Tour Now
          </button>
        </div>
      </div>

      <Footer />
    </div>
  );
}
